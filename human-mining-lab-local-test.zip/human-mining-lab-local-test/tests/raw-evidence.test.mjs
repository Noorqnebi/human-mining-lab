// Oracle grader tests: synthetic raw inputs, never a human-session acceptance claim.
import assert from 'node:assert/strict';
import {newEvidence,receiveEvidence} from '../testnet/oracle/generated/evidence.mjs';
import {interactionScore} from '../testnet/oracle/generated/interaction.mjs';
const frame={at:0,duration:4000,action:'select',answer:2,color:1,direction:1,options:[28,40,70,54],pattern:[0,1,2,1],x:60,y:50,cueStart:.3,cueEnd:.85};
const challenge=(action='select',mode='sequence')=>({id:'issued-challenge',startedAt:10000,durationMs:4000,mode,payload:{frames:[{...frame,action}]}});
const input=(kind='choice',extra={})=>({challengeId:'issued-challenge',nonce:'server-nonce',seq:1,frame:0,kind,value:2,...extra});
function grade(action,events){const c=challenge(action),s=newEvidence();events.forEach(([at,e],i)=>receiveEvidence(c,'server-nonce',s,{...input(e.kind,e),seq:i+1},at));return {s,result:interactionScore(c,s.trace)}}
let checks=0;const pass=(name,fn)=>{fn();checks++;console.log('PASS raw evidence:',name)};
for(const [name,mutate] of [['quality',e=>e.quality=1],['success',e=>e.success=true],['timestamp',e=>e.at=11000],['wrong nonce',e=>e.nonce='other'],['wrong challenge',e=>e.challengeId='other'],['wrong frame',e=>e.frame=1],['NaN',e=>e.x=NaN],['negative sequence',e=>e.seq=-1]])pass(name+' rejected',()=>{const e=input();mutate(e);assert.throws(()=>receiveEvidence(challenge(),'server-nonce',newEvidence(),e,11000))});
pass('correct selection independently passes',()=>assert(grade('select',[[11000,{kind:'choice',value:2}]]).result.success));
pass('wrong selection fails',()=>assert(!grade('select',[[11000,{kind:'choice',value:1}]]).result.success));
pass('memory cannot answer during reveal',()=>assert(!grade('memory',[[10500,{kind:'choice',value:1}]]).result.success));
pass('memory after reveal passes',()=>assert(grade('memory',[[12000,{kind:'choice',value:1}]]).result.success));
pass('short hold fails',()=>assert(!grade('hold',[[11000,{kind:'hold-down'}],[11100,{kind:'hold-up'}]]).result.success));
pass('server-timed hold passes',()=>assert(grade('hold',[[11000,{kind:'hold-down'}],[12500,{kind:'hold-up'}]]).result.success));
pass('hold without down fails',()=>assert(!grade('hold',[[12500,{kind:'hold-up'}]]).result.success));
pass('pattern before cue fails',()=>assert(!grade('pattern',[[10500,{kind:'tap'}]]).result.success));
pass('pattern during cue passes',()=>assert(grade('pattern',[[12000,{kind:'tap'}]]).result.success));
pass('gesture path passes correct direction',()=>assert(grade('swipe',[[11000,{kind:'pointer',phase:'down',x:20,y:50}],[11200,{kind:'pointer',phase:'up',x:80,y:50}]]).result.success));
pass('gesture path wrong direction fails',()=>assert(!grade('swipe',[[11000,{kind:'pointer',phase:'down',x:80,y:50}],[11200,{kind:'pointer',phase:'up',x:20,y:50}]]).result.success));
pass('duplicate sequence rejected',()=>{const c=challenge(),s=newEvidence(),e=input();receiveEvidence(c,'server-nonce',s,e,11000);assert.throws(()=>receiveEvidence(c,'server-nonce',s,e,11001))});
pass('completed challenge rejects input',()=>assert.throws(()=>receiveEvidence(challenge(),'server-nonce',newEvidence(),input(),14000)));
pass('unstarted challenge rejects input',()=>assert.throws(()=>receiveEvidence({...challenge(),startedAt:undefined},'server-nonce',newEvidence(),input(),11000)));
pass('one tracking point cannot claim sustained attention',()=>{const c=challenge('tap','tracking'),s=newEvidence();receiveEvidence(c,'server-nonce',s,input('track',{x:60,y:50,down:true}),11000);assert(!interactionScore(c,s.trace).success)});
pass('sustained coordinate tracking is recalculated',()=>{const c=challenge('tap','tracking'),s=newEvidence();for(let i=1;i<40;i++)receiveEvidence(c,'server-nonce',s,input('track',{x:60,y:50,down:true,seq:i}),10000+i*100);assert(interactionScore(c,s.trace).success)});

pass('hold cancellation breaks continuity',()=>assert(!grade('hold',[[11000,{kind:'hold-down'}],[11500,{kind:'hold-cancel'}],[12600,{kind:'hold-up'}]]).result.success));
pass('balance cannot pass by unattended natural drift',()=>{const events=Array.from({length:35},(_,i)=>[10100+i*100,{kind:'sample'}]);assert(!grade('balance',events).result.success)});
pass('balance with measured steering can pass',()=>{const events=[[10100,{kind:'steer',value:1}],[10400,{kind:'steer',value:0}],...Array.from({length:20},(_,i)=>[10500+i*100,{kind:'sample'}])];assert(grade('balance',events).result.success)});
pass('slider target check',()=>assert(grade('slider',[[12000,{kind:'choice',value:60}]]).result.success));
pass('color target check',()=>assert(grade('color',[[12000,{kind:'choice',value:1}]]).result.success));
pass('rhythm uses receipt-time gap',()=>assert(grade('rhythm',[[10500,{kind:'beat'}],[11500,{kind:'beat'}]]).result.success));
pass('resize raw pointer',()=>assert(grade('resize',[[11000,{kind:'pointer',phase:'down',x:65,y:65}],[11200,{kind:'pointer',phase:'up',x:77.5,y:50}]]).result.success));
pass('connect all three matching pairs',()=>{const events=[];for(let i=0;i<3;i++){events.push([11000+i*300,{kind:'pointer',phase:'down',x:18,y:20+i*30}],[11100+i*300,{kind:'pointer',phase:'up',x:82,y:20+[2,0,1].indexOf(i)*30}])}assert(grade('connect',events).result.success)});

pass('resize allows a correction after an off-target release',()=>assert(grade('resize',[[11000,{kind:'pointer',phase:'down',x:65,y:65}],[11100,{kind:'pointer',phase:'up',x:60,y:60}],[11200,{kind:'pointer',phase:'down',x:60,y:60}],[11300,{kind:'pointer',phase:'up',x:77.5,y:50}]]).result.success));
pass('dial permits correction within the same instruction',()=>{const p=a=>({x:50+34*Math.sin(a*Math.PI/180),y:50-34*Math.cos(a*Math.PI/180)});const events=[[11000,{kind:'pointer',phase:'down',...p(0)}],[11100,{kind:'pointer',phase:'up',...p(60)}],[11200,{kind:'pointer',phase:'down',...p(60)}],[11300,{kind:'pointer',phase:'up',...p(120)}]];assert(grade('dial',events).result.success)});
pass('wipe requires enough distinct coverage',()=>{const events=[[11000,{kind:'pointer',phase:'down',x:10,y:12.5}]];for(let i=0;i<20;i++)events.push([11100+i*50,{kind:'pointer',phase:'move',x:10+i%5*20,y:12.5+Math.floor(i/5)*25}]);assert(grade('wipe',events).result.success)});
pass('path accepts continuous points through the wide route',()=>{const path=[{x:15,y:70},{x:38,y:30},{x:61,y:65},{x:84,y:35}];const events=[[10100,{kind:'pointer',phase:'down',...path[0]}]];let at=10200;for(let i=1;i<path.length;i++)for(let j=1;j<=5;j++){events.push([at,{kind:'pointer',phase:'move',x:path[i-1].x+(path[i].x-path[i-1].x)*j/5,y:path[i-1].y+(path[i].y-path[i-1].y)*j/5}]);at+=100;}assert(grade('path',events).result.success)});
console.log(JSON.stringify({suite:'raw evidence',passed:checks}));
