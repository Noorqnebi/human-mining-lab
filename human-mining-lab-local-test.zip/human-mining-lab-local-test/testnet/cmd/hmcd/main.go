package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	cfg "github.com/cometbft/cometbft/config"
	cmtjson "github.com/cometbft/cometbft/libs/json"
	"github.com/cometbft/cometbft/libs/log"
	"github.com/cometbft/cometbft/node"
	"github.com/cometbft/cometbft/p2p"
	"github.com/cometbft/cometbft/privval"
	"github.com/cometbft/cometbft/proxy"
	"github.com/cometbft/cometbft/types"
	hm "hmc.local/testnet/x/humanmining"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

func die(e error) {
	if e != nil {
		panic(e)
	}
}
func config(root string, i int) *cfg.Config {
	c := cfg.DefaultConfig()
	c.SetRoot(filepath.Join(root, fmt.Sprintf("node%d", i)))
	c.Moniker = fmt.Sprintf("hmc-validator-%d", i+1)
	c.RPC.ListenAddress = fmt.Sprintf("tcp://127.0.0.1:%d", 26657+i*10)
	c.P2P.ListenAddress = fmt.Sprintf("tcp://127.0.0.1:%d", 26656+i*10)
	c.P2P.AllowDuplicateIP = true
	c.P2P.AddrBookStrict = false
	c.Consensus.TimeoutCommit = 2 * time.Second
	c.Consensus.CreateEmptyBlocks = true
	return c
}
func main() {
	if len(os.Args) < 3 {
		fmt.Println("hmcd init|start DATA_DIR [NODE_INDEX]")
		os.Exit(1)
	}
	root, _ := filepath.Abs(os.Args[2])
	switch os.Args[1] {
	case "init":
		if _, e := os.Stat(filepath.Join(root, "node0")); e == nil {
			panic("existing testnet retained; use reset script explicitly")
		}
		die(os.MkdirAll(root, 0700))
		oracle, oracleKey, e := ed25519.GenerateKey(rand.Reader)
		die(e)
		admin, adminKey, e := ed25519.GenerateKey(rand.Reader)
		die(e)
		die(os.WriteFile(filepath.Join(root, "oracle.seed"), []byte(hex.EncodeToString(oracleKey.Seed())), 0600))
		die(os.WriteFile(filepath.Join(root, "admin.seed"), []byte(hex.EncodeToString(adminKey.Seed())), 0600))
		vals := []types.GenesisValidator{}
		ids := []string{}
		for i := 0; i < 3; i++ {
			c := config(root, i)
			cfg.EnsureRoot(c.RootDir)
			die(os.MkdirAll(filepath.Dir(c.PrivValidatorStateFile()), 0700))
			pv := privval.LoadOrGenFilePV(c.PrivValidatorKeyFile(), c.PrivValidatorStateFile())
			pub, e := pv.GetPubKey()
			die(e)
			vals = append(vals, types.GenesisValidator{Address: pub.Address(), PubKey: pub, Power: 10, Name: c.Moniker})
			key, e := p2p.LoadOrGenNodeKey(c.NodeKeyFile())
			die(e)
			ids = append(ids, string(key.ID()))
		}
		genesis := &types.GenesisDoc{GenesisTime: time.Now().UTC(), ChainID: "hmc-private-1", InitialHeight: 1, ConsensusParams: types.DefaultConsensusParams(), Validators: vals, AppState: hm.Bytes(hm.NewState("hmc-private-1", hex.EncodeToString(oracle), hex.EncodeToString(admin)))}
		b, e := cmtjson.MarshalIndent(genesis, "", "  ")
		die(e)
		for i := 0; i < 3; i++ {
			c := config(root, i)
			peers := []string{}
			for j := 0; j < 3; j++ {
				if i != j {
					peers = append(peers, fmt.Sprintf("%s@127.0.0.1:%d", ids[j], 26656+j*10))
				}
			}
			c.P2P.PersistentPeers = strings.Join(peers, ",")
			cfg.WriteConfigFile(filepath.Join(c.RootDir, "config/config.toml"), c)
			die(os.WriteFile(c.GenesisFile(), b, 0600))
			die(os.WriteFile(filepath.Join(c.RootDir, "peers"), []byte(c.P2P.PersistentPeers), 0600))
		}
		fmt.Println("Initialized three validators, zero supply, native uhmc. Secret seeds saved server-side.")
	case "start":
		i := 0
		if len(os.Args) > 3 {
			i, _ = strconv.Atoi(os.Args[3])
		}
		if i < 0 || i > 2 {
			panic("node index must be 0–2")
		}
		c := config(root, i)
		peers, e := os.ReadFile(filepath.Join(c.RootDir, "peers"))
		die(e)
		c.P2P.PersistentPeers = string(peers)
		app, e := hm.Open(filepath.Join(c.RootDir, "data/humanmining.json"))
		die(e)
		pv := privval.LoadFilePV(c.PrivValidatorKeyFile(), c.PrivValidatorStateFile())
		key, e := p2p.LoadNodeKey(c.NodeKeyFile())
		die(e)
		n, e := node.NewNode(c, pv, key, proxy.NewLocalClientCreator(app), node.DefaultGenesisDocProviderFunc(c), cfg.DefaultDBProvider, node.DefaultMetricsProvider(c.Instrumentation), log.NewTMLogger(log.NewSyncWriter(os.Stdout)))
		die(e)
		die(n.Start())
		ch := make(chan os.Signal, 1)
		signal.Notify(ch, syscall.SIGINT, syscall.SIGTERM)
		<-ch
		die(n.Stop())
		n.Wait()
	default:
		panic("unknown command")
	}
}
