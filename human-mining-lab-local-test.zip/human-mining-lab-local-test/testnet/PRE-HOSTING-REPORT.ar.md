# Human Mining Lab — Pre-Hosting Hardening

تاريخ التحقق: 7 سبتمبر 2026. المشروع الحالي نفسه؛ لا استضافة جديدة ولا Public Testnet أو Mainnet أو أموال حقيقية.

**قرار الجاهزية: NO.** نجحت اختبارات مهمة على CometBFT الفعلية، لكن معيار المستخدم الأساسي — جلسة كاملة من المتصفح ثم Mint وتحويل وإعادة تشغيل وجلسة جديدة — لم يجتز القبول بعد. هذا تقرير نتائج وحدود، وليس شهادة أمنية أو إعلان اكتمال المهام الـ23.

## 1. Browser E2E

فُتحت الواجهة الحالية، ثم Mine → HMC Private Testnet. اتصلت المعاينة بالـOracle المحلي وظهرت حالة الشبكة الفعلية. عند Create encrypted wallet، لم يكن `crypto.subtle` متاحًا في سياق HTTP الخاص بالمعاينة الداخلية؛ فشل إنشاء المحفظة قبل Start Mining. لم تُنشأ معاملة تعدين من هذا المتصفح.

أضيف فحص مبكر برسالة واضحة: المحفظة تتطلب HTTPS أو localhost. لا يتم إرسال المفتاح للخادم ولا استبدال التشفير بتوقيع وهمي. لم نغيّر إعدادات أمن المتصفح لتجاوز هذا القيد. الاختبار المطلوب يجب إعادته من localhost آمن أو HTTPS خاص؛ لا يكفي نجاح المعاينة في عرض Blocks.

الربط المحلي اختياري عبر `HMC_LOCAL_TESTNET=1` في `.env.local`. إضافة Vite تعمل أثناء التطوير فقط، وتشغّل الشبكة والـOracle وتوجّه `/api/testnet` إليهما. لا تشغّل validators داخل Worker المنشور. لم تُنشر هذه التغييرات.

## 2. Real human session

**NOT RUN / BLOCKED.** لا توجد جلسة بشرية مكتملة يمكن نسبتها إلى هذا الفحص. التفاعل الآلي بالمتصفح، إن اكتمل، يثبت تكامل الواجهة فقط ولا يعادل دراسة إنسان فعلي. لا ننقل نتائج API القديمة أو الحالية إلى خانة Browser acceptance.

## 3–6. Mint، Transaction، Block، Wallet balances

اختبار `hardening-network.mjs` شغّل ثلاثة validators منفصلة فعلًا بمفاتيح وقواعد بيانات مستقلة. عمل التعدين في هذا الاختبار fixture اصطناعي معلن موقّع بمفتاح Oracle لشبكة اختبار منفصلة، وليس مكافأة مستخدم أو عملًا بشريًا.

المرجع الآلي الدقيق: `hardening-network-results.json`. أثبت الاختبار Mint قدره 4.5 HMC-Test، ثم تحويل 1 HMC-Test، ثم إعادة التشغيل، ثم Mint آخر وتحويل آخر. المعروض النهائي 9 HMC-Test، رصيد المرسل 7، ورصيد المستقبل 2. يحتوي المرجع على hashes والـheights والعناوين الفعلية. HMC-Test عملة أصلية في دفتر الشبكة؛ ليست ERC-20 أو SPL.

**جلسة API الجديدة بتوقيت فعلي 600 ثانية نجحت**، وتفاصيلها منفصلة في `raw-e2e-results.json`:

| القياس | النتيجة |
|---|---|
| Session ID | `c612e5a9-cfa7-4c59-9d80-763bc0e4bd62` |
| VHT | 478.676 ثانية في الشهادة |
| HU | 412.187 HU بعد التقريب الحتمي؛ metrics قبل التقريب 412.204558 |
| Challenges | 24؛ نجح 21، فشل 3، Missed = 0 |
| متوسط onset / density | 24.954 ثانية / 2.4 تحدٍ في الدقيقة |
| Continuous completed | 6 من 9 |
| Attention / Reliability / Efficiency | 82.80% / 99.99% / 86.11% في الشهادة |
| Difficulty / Epoch | 1.0 / 2981332 |
| Mint | 4.12187 HMC-Test |
| Transaction | `5F576BD73DEC0D9B8A3D06003B20E589078248FD7DED78790B86F6591B62216D` |
| Block | #262 |
| Proof hash | `59f1088ba5249bc260a21556740b94656708f479ce4d74b9c5c04dd1384a36d6` |
| Miner | `hmcdcadffda4854a48cd769586a0a7a1f5b3da63551` |
| الرصيد بعد تحويل 1 | 3.12187 HMC-Test للمرسل؛ 1 للمستقبل |
| Transfer hash | `7BAF89A2F19A442AF16ECE6B8130515DCE47371865B6CB74CF5FA1B812B6E436` |
| Replay / supply during transfer | رُفض التكرار؛ supply لم يتغير |

هذا client آلي يولّد raw inputs؛ ليس مستخدمًا بشريًا ولا جلسة Browser. بعض أنواع الأشكال لم يحلها driver عمدًا. لا تُحوّل هذه الأرقام إلى توقعات نجاح إنسان واحد.

## 7. Replay

نجح رفض إعادة الإثبات قبل إعادة التشغيل وبعدها. بقيت خرائط `usedSessions` و`usedProofs` و`usedNonces` محفوظة. الاستعلام عن المعاملة والـBlock القديمين عمل بعد إعادة التشغيل. التحويلات مربوطة بتوقيع صاحب الحساب وnonce متزايد؛ اختبارات Go ترفض إعادة التحويل.

أضيفت استعادة تأكيد Submit بعد انقطاع الرد: يبحث الـOracle عن نفس session/proof في الحالة الملتزم بها ويستعيد سجل RPC بدل إصدار مكافأة أخرى. زر Test replay protection يطلب إعادة إرسال فعلية لقياس الرفض؛ طلب الاستعادة الطبيعي لا يُعامل كمحاولة Mint جديدة.

## 8. Tampering tests

في كل صف: Expected = REJECTED. Actual = PASS يعني أن محاولة التلاعب رُفضت، لا أن المعاملة قُبلت.

| محاولة التلاعب | المستوى المختبر | Actual | سبب الرفض |
|---|---|---|---|
| HU، VHT، Attention، Reliability، success، duration النهائية | Oracle HTTP | PASS | حقول العميل النهائية غير مسموحة |
| عنوان المعدّن، epoch، hash، signature، expiry، sessionId، chain، reward المرسلة كقيم جلسة | Oracle HTTP | PASS | عقد مدخلات صارم؛ ليست حقولًا قابلة لتعديل الجلسة |
| تعديل HU/VHT/Attention/Reliability/challenge result/duration بعد التوقيع | RPC → ABCI | PASS | اختلاف التزام work أو التوقيع |
| تعديل miner address | RPC → ABCI | PASS | miner binding غير صالح |
| تعديل epoch أو sessionId أو challenge root أو final hash | RPC → ABCI | PASS | التزام الإثبات غير صالح |
| تعديل certificate expiry | RPC → ABCI | PASS | شهادة زمنية أو توقيع غير صالح |
| Oracle signature خاطئة | RPC → ABCI | PASS | Ed25519 verification |
| إضافة reward مباشرة للمعاملة | RPC → ABCI | PASS | حقل غير معرّف في رسالة canonical |
| duplicate mining proof | RPC → ABCI قبل/بعد restart | PASS | الإثبات سبق استخدامه أو المعاملة في cache |
| nonce أو challenge ID خاطئان في raw event | Raw grader | PASS | عدم مطابقة التحدي المصدر |
| quality/success/timestamp داخل raw event | Raw grader | PASS | حقول غير معروفة |
| hold قصير أو بدون ضغط سابق | Raw grader | PASS | مدة يقيسها الخادم غير كافية |
| إجابة memory أثناء العرض أو pattern قبل الإشارة | Raw grader | PASS | شرط التوقيت غير متحقق |
| نقطة tracking واحدة بدل متابعة مستمرة | Raw grader | PASS | تغطية زمنية غير كافية |
| بدء challenge بعد 4 ثوانٍ | Oracle بتوقيت فعلي | PASS | Missed؛ لم يعد متاحًا للبدء |
| proof/epoch/day/max-supply caps | Go protocol tests | PASS | فحوص الحدود داخل State.Apply؛ ليست تجارب ضغط RPC للحدود |

هذه اختبارات تعديل حقول وتوقيعات ومدخلات محددة. اجتاز grader الخام 32 حالة. وُجد Bug حقيقي في Balance: الانجراف الطبيعي قد يحقق شرط الثبات دون أي توجيه؛ أضيف اشتراط 200ms من التوجيه الفعلي في renderer والـOracle، مع اختبار نجاح موجّه وفشل بلا تفاعل. لا تدّعي إثبات جميع مسارات الهجوم. تفاصيل RPC الفعلية في ملف النتائج، والاختبارات قابلة للإعادة من مجلد `tests` و`testnet/scripts`.

## 9. Multi-window results

**NOT RUN كدراسة إنسان واحد في 1/2/3 نوافذ.** لا نملك نتائج miss rate/latency/HU/reward بشرية موثوقة، ولا نستبدلها بمحاكاة. اختبارات تزامن Oracle تؤكد أن انتظار تأكيد معاملة لا يحجب pulses لجلسة أخرى؛ هذا اختبار تزامن خدمات فقط.

إجراء القبول المتبقي: نفس المختبر، 10 دقائق لكل حالة، ترتيب حالات متبدل، ثلاث محاولات لكل حالة، تسجيل session IDs وربط نوافذ التجربة، استخراج misses/latency/focus/HU/efficiency/reward الفعلية. احسب مجموع reward لكل دقيقة من زمن الإنسان، لا مجموع كفاءة الحسابات فقط. لا تفرض انخفاضًا مصطنعًا ولا تستنتج Sybil resistance من عينة صغيرة.

## 10. Restart / recovery

| السيناريو | النتيجة |
|---|---|
| Oracle stop/start | PASS: أرصدة الشبكة وسجلها ومنع replay بقيت |
| Validator stop/start | PASS: تعافى ولحق بالشبكة |
| Full stop/start بنفس البيانات | PASS: نفس chain، balances، nonces، transactions، used proofs |
| الاستعلام عن tx وblock قديمين بعد restart | PASS |
| Mint جديد وتحويل بعد restart | PASS مع fixture بروتوكول اصطناعي |
| Browser refresh أثناء/بعد جلسة حقيقية | NOT RUN بسبب عائق المحفظة |
| ملف ledger مشوّه/null/ناقص أو supply غير مطابق | PASS في Go: يفشل الفتح بدل تهيئة صامتة |

سلوك الاستعادة في الكود: wallet vault مشفر في localStorage ويحتاج unlock بعد refresh؛ معرف الجلسة وtoken في sessionStorage داخل نفس التبويب. Oracle restart يعلّم الجلسات غير المكتملة interrupted بدل المصادقة عليها. الجلسات المكتملة وشهاداتها تحفظ. شهادة لم تُنشأ خلال 30 ثانية من اكتمال الجلسة لا تُنشأ لاحقًا؛ الشهادة المنشأة تنتهي حسب expiry. لا يوجد استئناف مضمون بعد crash أثناء تحدٍ، ولا ضمان نجاة من فقد قرص كامل.

الكتابة تستخدم fsync ثم rename. هذا ليس اختبار انقطاع طاقة أو نسخ احتياطي موثّق أو استعادة تلف عشوائي لقاعدة CometBFT؛ هذه بوابات متبقية.

## 11. Validator failure

مع 3 أصوات متساوية، إيقاف validator واحد أبقى 2/3 فقط، فتوقفت commits. عند إعادته استؤنفت Blocks وتأكد الاختبار من اللحاق وعدم بقاء `catching_up`. التوصية للمرحلة التالية **4 validators متساوية على مضيفين مستقلين**: بقاء 3/4 يسمح بتحمل فقد واحد. لم نغيّر العدد الحالي. وجود ثلاثة processes على نفس المضيف لا يعطي تحمل تعطل ذلك المضيف.

## 12. Supply integrity

السلسلة المختبرة: Mint → Transfer → Oracle restart → validator outage/recovery → Full restart → Replay rejection → Mint → Transfer.

فُحصت المساواة: مجموع balances = supply = مجموع mining receipts = مجموع epoch mint = مجموع daily mint. بقي supply ثابتًا مع Transfer، وnonce النهائي 2، وproof/session/nonce claims محفوظة. قواعد max supply وday/epoch/proof caps نجحت في اختبارات وحدة البروتوكول. لا ندّعي أنها اجتازت بعد اختبار تحميل طويل أو سلسلة ترقيات/تغييرات parameters عبر أيام متعددة.

## 13. Frontend trust المتبقية

| المدخل/الادعاء | ما يفعله الخادم | ما يبقى قابلًا للتزوير |
|---|---|---|
| HU/VHT/Attention/Reliability/final reward | يرفض القيم النهائية ويعيد الحساب | مدخلات متناسقة اصطناعية قد تنتج درجات عالية |
| session ID، start، duration، challenge، nonce | ينشئها الخادم؛ الطلب الأول موقّع من wallet | bot يمتلك wallet يستطيع طلب جلسة |
| choice/key/pointer/hold edges | تقييم مقابل الحالة الصادرة وتوقيت الاستلام | إحداثيات ومفاتيح اصطناعية؛ لا إثبات أصل حسّي |
| focus/visibility | توقف accrual بعد تقرير الخلفية؛ lease ثانية واحدة عند انقطاع pulses | تعديل العميل ليقول focused دائمًا |
| chain root | سلسلة متولدة بالخادم مع hash للأدلة الخام | Oracle خبيث يمكنه اختلاق السلسلة كلها |

لا توجد timestamps عميل معتمدة لحساب زمن الأدلة. server receipt time يؤثر فيه تأخير الشبكة وتجمّع الطلبات؛ يلزم قياس false negatives بالمتصفح خاصة قرب حدود التعليمات. فحص تطابق كل عائلة من 16 renderer مع grader الجديد لم يكتمل بصريًا بعد. هذا blocker فعلي، لا مجرد تحسين اختياري.

## 14. Oracle trust / Security boundary

| الطبقة | تثق في | تتحقق من | الحماية التشفيرية | المركزية |
|---|---|---|---|---|
| Browser | تطبيقه وendpoint المحدد | wallet backup identity والتشفير المحلي | Ed25519 wallet + PBKDF2/AES-GCM vault | يمكن تعديل JavaScript؛ RPC غير light-client |
| Oracle | ساعة/كود الخادم؛ ادعاءات focus؛ أصل raw input غير مثبت | session auth، nonce، sequence، response deadline، timing، raw actions، challenge chain، HU | توقيع شهادة Ed25519 وحفظ commitment للأدلة | مُصدِر شهادات وحيد؛ يستطيع اختلاق عمل متسق |
| Blockchain | oracle public key الخاص بالـepoch؛ validator quorum | canonical bytes، signature، bindings، epochs، expiry، work bounds، HU formula، caps، replay | signatures + SHA-256 + CometBFT commits | admin ومعرّف Oracle واحد؛ لا human verification decentralized |

التوقيع يحمي سلامة الشهادة وهوية الموقّع، لا صدق وجود إنسان. CometBFT مسؤول عن consensus؛ Human Mining مسؤول عن issuance فقط.

## 15. Threat model v0.1

الاحتمالات تقديرات نوعية لشبكة خاصة، وليست قياسات إحصائية.

| Threat | Likelihood | Impact | التخفيف الحالي | الخطر المتبقي | الإصلاح المطلوب |
|---|---|---|---|---|---|
| Malicious browser | High | High | final fields مرفوضة؛ raw grading | raw evidence/focus اصطناعيان | independent verification واختبار renderer latency |
| Bot | High | High | timing/continuity/caps | bot يمكنه إنتاج inputs صحيحة | بروتوكول تحقق متعدد ومقاييس بحثية صادقة |
| Multi-window miner | High | Medium | عشوائية ومتابعة وfocus accounting | focus قابل للتزوير؛ لا قياس بشري مكتمل | دراسة 1/2/3 نوافذ فعلية |
| Stolen wallet | Medium | High | vault مشفر ومفتاح unlocked غير قابل للتصدير | XSS أو تسريب passphrase قادر على التوقيع | external signer، CSP ومراجعة frontend |
| Stolen oracle key | Medium | Critical | seed خارج frontend؛ caps/epoch rotation | Mint مصطنع ضمن الحدود | signer معزول/HSM، rotation drills، immediate pause مصمم |
| Malicious oracle | Medium | Critical | limits وpublic audit trail | يمكنه اختلاق عمل صالح شكليًا | independent/threshold verifiers |
| Validator offline | High | High | recovery اختبر فعليًا | 1 من 3 يوقف الشبكة | 4 مستقلة، monitoring، failover منضبط |
| Byzantine validator | Medium | Critical | CometBFT consensus | تجاوز fault threshold أو تحكم مشترك | فصل المشغلين، مراجعة config، Byzantine testing |
| Replay attack | High | Medium | session/proof/nonce/epoch/expiry | فقد state أو reset ملتبس | backup drills وchain ID جديد لكل reset دائم |
| Forged certificate | High | High | Ed25519 + canonical hash | سرقة المفتاح/خطأ parser غير مكتشف | fuzzing، مستقلة security review |
| RPC attack | Medium | High | loopback؛ لا أسرار في state | proxy بلا auth/limits؛ استجابة RPC كاذبة | authenticated gateway، allowlist، light client لاحقًا |
| DDoS / state growth | High إذا كُشف | High | body/event/session bounds | لا gas؛ full JSON/history يعاد قراءته وكتابته | quotas/rate limits، bounded queries، SDK storage |
| Admin key compromise | Medium | Critical | توقيع وnonce وnext epoch | تغيير Oracle/caps؛ pause غير فوري | multisig/offline admin، audit، key separation |
| Corrupt local DB | Medium | High | fsync/rename وفحوص بنيوية | تلف قرص/سجل خبيث متناسق | backups مع hashes، restore drills، DB/migration tooling |
| Double transfer | High | High | توقيع وnonce ورصيد، تطبيق ذري | concurrency/load لم يُختبر على نطاق واسع | mempool/load tests، SDK auth/bank |

## 16. HMP/0.1 Candidate Freeze

**مرشح فقط، ليس freeze نهائيًا.**

| Parameter / component | Classification | القرار |
|---|---|---|
| version `HMP/0.1`، ترتيب canonical signed fields، SHA-256، Ed25519 certificate | Freeze for v0.1 | أي تغيير يحتاج version/decoder منفصلًا |
| denomination `uhmc`؛ 1 coin = 1,000,000 units | Freeze for v0.1 | Native coin؛ لا تحويل simulation |
| HU milli-units، score basis points، difficulty millionths، integer reward floor | Freeze for v0.1 | الحفاظ على test vectors |
| session/proof/nonce uniqueness، miner/chain/epoch binding | Freeze for v0.1 | لا تخفيف replay rules |
| epoch length 600s | Freeze for v0.1 | الكود يرفض مدة أخرى حاليًا |
| session 10/20/30/60، response 4s، challenge mix/timing | Experimental baseline | لا تغيير صعوبة فكرية؛ settings snapshot |
| difficulty، pool/reference، caps، min/max HU، expiry، oracle key، pause | Experimental | صلاحية admin موقّعة وفعالية epoch؛ حدود ValidateParams |
| max supply 1B test coins | Experimental | لا قرار tokenomics نهائي |
| raw evidence format وtolerance | Experimental | ليس جزءًا مجمدًا حتى renderer acceptance كامل |
| client focus كدليل حضور بشري | Unsafe / Needs redesign | لا يجوز عرضه كإثبات إنسان |
| custom wallet/address/auth؛ full-state JSON؛ لا gas | Unsafe للانتقال الإنتاجي | migration قبل persistent infrastructure الموصى بها |
| pause next epoch فقط، Oracle واحد، 3 على مضيف واحد | Needs redesign قبل التوسع | فصل authority وavailability |

## 17. Custom ABCI vs Cosmos SDK — قرار تقني

**التوصية: Migrate before persistent hosting.** يمكن إبقاء Custom ABCI محليًا للبحث، لكن بناء تشغيل دائم حول wallet/auth/storage/upgrade primitives المخصصة يزيد تكلفة إعادة العمل والمخاطر. لا نفّذ migration جزئية: نقل التوقيع والحسابات والمحفوظات يحتاج اختبارات توافق وإعادة قبول كاملة.

| جانب | Custom ABCI الحالي — من الكود | Cosmos SDK target |
|---|---|---|
| Security | `Decode/Apply` وledger مخصصان، مراجعة صغيرة واختبارات محدودة | primitives قياسية؛ ما زال x/humanmining يحتاج audit |
| Wallets / Bech32 | hmc + hex، Ed25519 محلي، لا checksum/Keplr | Bech32 وsecp256k1 وexternal signer |
| Transactions | canonical JSON يدوي، signed nonce، لا gas | protobuf Tx/AuthInfo/SignDoc وante validation |
| Auth | دالة signature + Nonces map | x/auth account number/sequence/signing |
| Bank | Balances/Supply maps وMsgSend يدوي | x/bank، module account بصلاحية mint محدودة |
| Governance | admin key منفرد، update next epoch | authority/multisig؛ governance حسب نطاق الخاصة |
| Upgrades | لا store migrations أو upgrade handlers | x/upgrade مع خطة stores ومشغل node |
| IBC readiness | غير موجود؛ لا authenticated store proofs | ممكن بعد إضافة modules/config؛ ليس تلقائيًا |
| Explorer ecosystem | JSON RPC viewer خاص | REST/gRPC/indexers وواجهات ecosystem قياسية |
| Validator tooling | CometBFT processes/configs حقيقية | CometBFT أيضًا مع SDK CLI/genesis/operational tooling |
| Maintenance | كل ledger/history/auth edge case علينا؛ whole-state clone/write | اعتمادات أكثر لكن primitives أقل لإعادة اختراعها |
| Migration complexity | منخفض للبقاء محليًا؛ يزداد مع مستخدمين وتاريخ دائم | مرتفع الآن، لكنه أقل قبل تثبيت البنية الدائمة |
| Mainnet suitability | NO | ليس YES تلقائيًا؛ oracle trust والأمان والاقتصاد لم تُحل |

هذا التقييم يستند إلى `app.go` (whole-state clone/fsync)، `protocol.go` (custom Apply)، `client.ts` (custom vault/address)، `main.go` (embedded CometBFT). الوظائف القياسية المرجعية: [Cosmos transactions](https://docs.cosmos.network/sdk/latest/learn/concepts/transactions)، [x/auth](https://docs.cosmos.network/sdk/latest/modules/auth/auth)، [x/bank](https://docs.cosmos.network/sdk/latest/modules/bank/README). ترميز [Bech32](https://docs.cosmos.network/sdk/latest/guides/reference/bech32) ودعم [Keplr suggest chain](https://docs.keplr.app/api/guide/suggest-chain) لا يتحققان بمجرد تغيير بادئة العنوان الحالي.

خطة migration كاملة، دون تعديل الشبكة الحالية:

1. إنشاء branch مستقل من snapshot الحالي؛ تجميد bytes/test vectors للشهادات ومخرجات Reward. إبقاء Lab/challenges كما هي.
2. اختيار إصدار SDK مدعوم ومتوافق مع CometBFT بعد فحص security advisories؛ إضافة BaseApp/auth/bank/upgrade، ثم x/humanmining keeper وprotobuf messages/queries.
3. نقل Work/Certificate validator وinteger math حرفيًا مع golden vectors. حفظ envelope/signature bytes القديمة كما هي أثناء التحقق؛ لا إعادة JSON serialization غير متوافقة. Mint فقط بواسطة module account ثم SendCoins إلى المعدّن.
4. توفير transaction sender قياسي وwallet adapter وREST/gRPC؛ Oracle interface يبقى مستقلًا خلف verifier abstraction. لا تستبدل توقيع oracle بتوقيع wallet.
5. شبكة migration تجريبية جديدة مع chain ID مميز. تصدير native ledger فقط من ارتفاع متفق عليه، مع supply/nonces/claims/epochs/hashes وسجل تدقيق. تبقى simulation خارج genesis.
6. mapping موقّع بين العنوان القديم والعنوان الجديد؛ لا اشتقاق secp256k1 من Ed25519 أو تحويل private keys صامتًا. خيار الاحتفاظ بالشبكة القديمة read-only وإصدار أرصدة snapshot native فقط بعد إثبات الملكية؛ منع claims المكررة. لا محو تاريخ قديم.
7. مقارنة balances/supply/HU/reward/replay، ثم upgrade/restart/validator failure tests. التاريخ القديم يعرض بوسم chain ID/legacy؛ لا hash قديم يُنسب إلى Block جديد.
8. Browser acceptance كامل وrollback rehearsal قبل قرار persistent hosting. لا IBC bridge ولا أموال عامة ضمن هذه الخطة.

## 18. Wallet migration

الـvault الحالي يبقى قابلًا للفتح والتصدير المشفر. أضف لاحقًا adapter لـKeplr/standard signing، native denomination metadata، Bech32 HRP، chain-specific account/sequence، external signer. لا يكفي تغليف الـhex الحالي بـBech32: نوع المفتاح واشتقاق العنوان ورسالة التوقيع مختلفة. تحقق من mapping بهوية المفتاح القديم وتوقيع من المحفظة الجديدة، واحتفظ بسجل migration قابل للمراجعة.

## 19. Hosting readiness / next architecture

لم تُنفذ الاستضافة. الأرقام التالية ميزانية هندسية أولية لشبكة خاصة صغيرة، وليست سعة مثبتة بالتحميل أو عرض شراء:

| مكوّن | نقطة بداية | العزل المطلوب |
|---|---|---|
| 4 validators | لكل واحد 2–4 vCPU، 4–8GB RAM، 100GB SSD قابل للتوسعة | 4 مضيفين/نطاقات أعطال؛ مفتاح مستقل لكل validator |
| Oracle/verifier | 2–4 vCPU، 4GB RAM، قرص مشفر/backup | مضيف منفصل؛ signer غير قابل للوصول من frontend |
| RPC/sentry | 2 vCPU، 4GB RAM، قرص بحسب retention | private ingress؛ لا تعريض validator RPC مباشرة |
| Frontend | الاستضافة الحالية بعد القبول | HTTPS، وصول خاص، gateway مصادق عليه |

Checklist قبل النقل:

- [ ] Browser E2E وrenderer grading acceptance كاملان على HTTPS/localhost.
- [ ] migration decision منفذة أو قبول مخاطر موثق للبقاء المحلي المحدود.
- [ ] validator separation، process supervision، graceful shutdown، منع double signing.
- [ ] reverse proxy + TLS renewals + DNS + firewall default-deny.
- [ ] RPC allowlist/read limits، broadcast authentication/rate limits، request timeouts، لا CORS كبديل auth.
- [ ] أسرار Oracle/admin منفصلة، least privilege، rotation/revocation rehearsal، لا أسرار في logs.
- [ ] metrics/alerts للheight stall، peer loss، Oracle lag، errors، caps، disk، CPU/RAM.
- [ ] backup مشفر خارج المضيف مع hashes وrestore test؛ لا تشغيل نسختين من validator signing state.
- [ ] log retention محدد (بداية 14 يومًا operational، audit أطول حسب البحث)، redaction، raw evidence privacy/retention policy.
- [ ] uptime monitoring من خارج المضيف، incident runbook وoperator مسؤول.
- [ ] load test وعدّ نمو state/history/raw evidence قبل تثبيت disk/CPU budgets.
- [ ] schema/store migrations، rollback، software advisories ومراجعة صلاحيات admin.

لا تضع Oracle وadmin key وكل validators على جهاز واحد وتسمّي ذلك fault isolation. sentry ليس بديلًا عن validator رابع إذا ظل التصويت 3 متساويين.

## 20. Exact remaining blockers / final acceptance

1. بيئة Browser آمنة تدعم WebCrypto، ثم جلسة UI كاملة؛ لم تُنفذ ولا يوجد hash ناتج عن هذه الواجهة.
2. مطابقة grader الجديد مع كل renderer، بما فيها keyboard/cancel/focus/latency وأجهزة touch؛ API tests لا تكفي.
3. إعادة الاختبار الكامل من نفس الواجهة: wallet → mining → proof/sign → submit → mint → balance/tx/block/proof → transfer 1 → replay → full restart → session جديدة.
4. تجربة فعلية لإنسان واحد مع 1/2/3 نوافذ؛ لا توجد أرقام معتمدة بعد.
5. Browser refresh واستعادة جلسة/محفظة وشهادة بعد انقطاع الرد، واختبار Oracle restart أثناء الجلسة، لا مجرد حفظ ledger.
6. عزل البنية ومفاتيحها، auth/rate limiting، backups/restore/load tests، retention ومراقبة، وإغلاق فجوة pause الطارئ.
7. تنفيذ migration SDK كاملة أو قرار تشغيل بحثي محدود مستقل موثق؛ لم تبدأ migration جزئية.

**Is HMC Private Testnet ready to be moved from local PoC to persistent private infrastructure? NO.** نجاح consensus وMint/Transfer/Replay/Restart خطوة حقيقية، لكنه لا يعوّض غياب Browser → Human Mining → Native Coin acceptance المستقر.


## متابعة 8 سبتمبر 2026

حالة الجاهزية ما زالت **NO**؛ نتائج جلسة API يوم 7 سبتمبر لم تُعد تصنيفها كاختبار Browser.

- نجح اختبار إعادة تشغيل عملية Oracle فعلية بعد إنشاء ثلاث جلسات موقعة متزامنة. حفظ الإغلاق المنظم بيانات الجلسات، وأتاح بعد الإقلاع قراءة حالتها interrupted دون إصدار شهادة، ورفض token خاطئًا، وسمح ببدء جلسة جديدة. RPC في هذا الاختبار stub صريح؛ ليس اختبار mint أو تجربة إنسان مع ثلاث نوافذ.
- الواجهة توقف polling للجلسة interrupted وتعرض سبب الانقطاع وزر بدء جلسة جديدة. هذا التغيير اجتاز TypeScript والبناء؛ لم يُختبر browser mining بسبب القيد السابق.
- أُصلح اختلاف grader عن renderer في Dial وResize: الإفلات غير الدقيق لا يمنع التصحيح ضمن وقت التعليمة. اختبارات raw evidence أصبحت 36 حالة، بما فيها wipe وpath وتصحيح dial/resize.
- أضيف `node testnet/scripts/start-local-lab.mjs` لتشغيل المشروع نفسه على loopback وlocalhost مع الشبكة المحلية دون تحرير إعدادات يدويًا. يفحص المتطلبات ويحافظ على data directory؛ لا reset ولا نشر. فُحص خيار `--check` فعليًا، أما إطلاقه من متصفح المستخدم والجلسة الكاملة فما زالا غير مجتازين هنا.
- اختبار Oracle restart أثناء جلسة لم يعد مجهولًا على مستوى الخدمة: سياسة المقاطعة وبدء جلسة جديدة اختُبرت. اختبار browser refresh/recovery مع محفظة وتحدٍ فعلي ما زال blocker.

لإجراء الاختبار المتبقي من نسخة المشروع المحلية المثبتة:

```bash
node testnet/scripts/start-local-lab.mjs
```

افتح localhost:4173 في متصفحك. من Mine اختر HMC Private Testnet، أنشئ wallet وصدّر backup المشفر، اختر 10 دقائق، وأكمل التحديات ثم Submit. سجّل tx/block/proof والرصيد. أنشئ wallet مستقبلة بملف متصفح منفصل واحتفظ بمفتاحها؛ حوّل 1 HMC-Test، افحص supply، جرّب replay. أعد التشغيل دون reset، وافحص السجل ثم أكمل جلسة جديدة. لا تغيير DNS أو استضافة دائمة مطلوب لهذه التجربة.
