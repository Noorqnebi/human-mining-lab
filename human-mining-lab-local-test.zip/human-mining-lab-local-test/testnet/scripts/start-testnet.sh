#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
export HMC_DATA_DIR="${HMC_DATA_DIR:-$PWD/testnet/.data}"
mkdir -p "$HMC_DATA_DIR"
chmod 700 "$HMC_DATA_DIR"
if [ ! -x testnet/bin/hmcd ]; then (cd testnet && go build -o bin/hmcd ./cmd/hmcd); fi
if [ ! -d "$HMC_DATA_DIR/node0" ]; then testnet/bin/hmcd init "$HMC_DATA_DIR"; fi
for i in 0 1 2; do
 pidfile="$HMC_DATA_DIR/node$i.pid"
 if [ -f "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then continue; fi
 nohup testnet/bin/hmcd start "$HMC_DATA_DIR" "$i" > "$HMC_DATA_DIR/node$i.log" 2>&1 &
 echo $! > "$pidfile"
done
node testnet/oracle/compile.mjs
if [ ! -f "$HMC_DATA_DIR/oracle.pid" ] || ! kill -0 "$(cat "$HMC_DATA_DIR/oracle.pid")" 2>/dev/null; then
 nohup node testnet/oracle/server.mjs > "$HMC_DATA_DIR/oracle.log" 2>&1 &
 echo $! > "$HMC_DATA_DIR/oracle.pid"
fi
printf 'Started three local CometBFT validators and oracle. RPC: 26657 / 26667 / 26677. API: 8788.\n'
if [ "${1:-}" = '--foreground' ]; then
 trap 'bash testnet/scripts/stop-testnet.sh; exit' INT TERM
 wait
fi
