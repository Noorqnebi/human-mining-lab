// Private testnet operator only. Never import this script into the browser.
import fs from 'node:fs';
import path from 'node:path';
import {createPrivateKey,sign} from 'node:crypto';
const file=process.argv[2];if(!file){console.error('Usage: node testnet/scripts/admin.mjs parameter-patch.json');process.exit(1)}
const base=process.env.HMC_API||'http://127.0.0.1:8788';const res=await fetch(base+'/state');if(!res.ok)throw Error('Oracle API unavailable');const {state}=await res.json();
const patch=JSON.parse(fs.readFileSync(file,'utf8'));const params={...state.params,...patch};
// Preserve the protocol field ordering required by canonical transaction encoding.
const admin={chainId:state.chainId,nonce:state.adminNonce+1,effectiveEpoch:Math.floor(state.timestamp/state.params.epochSeconds)+1,params};
const seed=process.env.HMC_ADMIN_SEED||fs.readFileSync(path.join(process.env.HMC_DATA_DIR||'testnet/.data','admin.seed'),'utf8');const key=createPrivateKey({key:Buffer.concat([Buffer.from('302e020100300506032b657004220420','hex'),Buffer.from(seed.trim(),'hex')]),format:'der',type:'pkcs8'});
const tx={type:'MsgUpdateParameters',admin,signature:sign(null,Buffer.from(JSON.stringify(admin)),key).toString('hex')};const r=await fetch(base+'/broadcast',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(tx)});const v=await r.json();if(!r.ok)throw Error(v.error);console.log(JSON.stringify({hash:v.hash,height:v.height,effectiveEpoch:admin.effectiveEpoch},null,2));
