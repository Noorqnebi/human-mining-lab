// Real-time API integration: scripted interactions, NOT a human/browser usability test.
import {generateKeyPairSync,sign,createHash,randomUUID} from 'node:crypto';
import assert from 'node:assert/strict';
const base=process.env.HMC_API||'http://127.0.0.1:8788';
const {privateKey,publicKey}=generateKeyPairSync('ed25519');const pub=publicKey.export({type:'spki',format:'der'}).subarray(-32).toString('hex'),address='hmc'+createHash('sha256').update(Buffer.from(pub,'hex')).digest('hex').slice(0,40);
async function call(path,body,token){const r=await fetch(base+path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{})});const v=await r.json();if(!r.ok)throw Error(v.error);return v}
const request={chainId:'hmc-private-1',address,minutes:10,nonce:randomUUID(),issuedAt:Date.now()};let s=await call('/session/start',{request,publicKey:pub,signature:sign(null,Buffer.from(JSON.stringify(request)),privateKey).toString('hex')});const id=s.session.id,token=s.token;console.log('Started real-time 600-second API session',id);let answered=new Map(),last=0,seqs={};
while(!s.completed){let events=[],c=s.session.pending;if(c&&!c.startedAt){try{s=await call('/session/begin',{id,challengeId:c.id,nonce:c.attentionNonce},token);c=s.session.pending}catch{}}
 if(c?.startedAt){const elapsed=Date.now()-c.startedAt,frames=c.payload.frames,i=frames.findLastIndex(f=>elapsed>=f.at),f=frames[i],key=c.id+':'+i;
 const emit=(kind,extra={})=>events.push({challengeId:c.id,nonce:c.attentionNonce,seq:seqs[c.id]=(seqs[c.id]||0)+1,frame:i,kind,...extra});
 if(f&&elapsed<c.durationMs-200){const dt=elapsed-f.at,st=answered.get(key)||{};answered.set(key,st);
 if(c.mode==='tracking'||c.mode==='adjust'){const prev=frames[Math.max(0,i-1)],t=Math.min(1,dt/f.duration),ease=t*t*(3-2*t);emit('track',{x:prev.x+(f.x-prev.x)*ease,y:c.mode==='adjust'?50:prev.y+(f.y-prev.y)*ease,down:true})}
 else if(!st.done){
 if(f.action==='hold'){if(!st.down&&dt>150){emit('hold-down');st.down=Date.now()}else if(st.down&&Date.now()-st.down>=Math.min(1500,f.duration*.5)+100){emit('hold-up');st.done=true}}
 else if(f.action==='rhythm'){if(!st.beat&&dt>150){emit('beat');st.beat=Date.now()}else if(st.beat&&Date.now()-st.beat>=800+f.cueStart*1000){emit('beat');st.done=true}}
 else if(dt>f.duration*.55&&dt<f.duration*.8){
 if(['select','memory','color','slider','spotlight'].includes(f.action))emit('choice',{value:f.action==='select'||f.action==='spotlight'?f.answer:f.action==='slider'?f.x:f.color});
 else if(f.action==='tap')emit('tap',{x:f.x,y:35});else if(f.action==='pattern')emit('tap');else if(f.action==='swipe')emit('swipe-key',{value:f.direction});
 else if(f.action==='drag'){emit('pointer',{phase:'down',x:10,y:50});emit('pointer',{phase:'up',x:f.x,y:f.y})}
 else if(f.action==='resize'){emit('pointer',{phase:'down',x:60,y:60});emit('pointer',{phase:'up',x:50+(45+f.color*10)/2,y:50})}
 else if(f.action==='wipe'){emit('pointer',{phase:'down',x:10,y:12.5});for(let y=12.5;y<100;y+=25)for(let x=10;x<100;x+=20)emit('pointer',{phase:'move',x,y})}
 // Path/dial/balance/connect intentionally not auto-solved by this API driver.
 st.done=true;
 }
 }
 }}
 try{s=await call('/session/pulse',{id,focused:true,events},token)}catch(e){if(!/instruction|window|active focused/.test(e.message))throw e;s=await call('/session/pulse',{id,focused:true,events:[]},token)}
 if(s.session.challenges.length!==last){last=s.session.challenges.length;console.log('Challenge',last,s.session.challenges.at(-1).status,'VHT',Math.round(s.metrics.vht))};await new Promise(r=>setTimeout(r,100));}
console.log('Session complete',JSON.stringify({vht:s.metrics.vht,hu:s.metrics.hu,efficiency:s.metrics.efficiency,count:s.session.challenges.length}));s=await call('/session/certificate',{id},token);assert(s.certificate);const signed=s.certificate;
const tampered=structuredClone(signed);tampered.certificate.work.humanUnits++;await assert.rejects(()=>call('/broadcast',tampered));console.log('PASS modified HU rejected by chain');
for(let retry=0;;retry++){try{s=await call('/session/submit',{id},token);break}catch(e){if(retry>=3||!String(e).includes('certificate time'))throw e;await new Promise(r=>setTimeout(r,2000))}}assert(s.transaction.hash);const chain=await call('/state');const balance=chain.state.balances[address];assert(balance>0);console.log('PASS native mint confirmed',JSON.stringify({hash:s.transaction.hash,height:s.transaction.height,balanceUhmc:balance,validators:chain.validators.total}));
await assert.rejects(()=>call('/session/submit',{id,replay:true},token),/already claimed/);console.log('PASS replay rejected');
const to='hmc'+createHash('sha256').update(randomUUID()).digest('hex').slice(0,40);const transfer={chainId:'hmc-private-1',from:address,to,amount:1000000,nonce:1};const tr=await call('/broadcast',{type:'MsgSend',transfer,publicKey:pub,signature:sign(null,Buffer.from(JSON.stringify(transfer)),privateKey).toString('hex')});assert(tr.hash);const after=await call('/state');assert.equal(after.state.supply,chain.state.supply);assert.equal(after.state.balances[to],1000000);assert.equal(after.state.balances[address],balance-1000000);assert(after.state.transactions.some(t=>t.hash===s.transaction.hash.toLowerCase()));console.log('PASS native transfer, balance update and explorer history');
console.log('RESULT: real three-validator API integration passed; no browser or human identity assertion.');

const fs=await import('node:fs');fs.writeFileSync('testnet/raw-e2e-results.json',JSON.stringify({kind:'600-second real-time scripted API, NOT browser or human test',date:new Date().toISOString(),sessionId:id,metrics:s.metrics,work:s.certificate.certificate.work,hash:s.transaction.hash,block:s.transaction.height,balanceBeforeTransfer:balance,balances:after.state.balances,transfer:tr.hash,replayRejected:true,supplyUnchangedByTransfer:true},null,2));
