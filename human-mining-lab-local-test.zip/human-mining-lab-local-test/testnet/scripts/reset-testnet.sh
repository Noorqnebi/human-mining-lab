#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
if [ "${1:-}" != '--confirm-testnet-reset' ]; then echo 'Resets native testnet only. Run with --confirm-testnet-reset. Existing data is archived, never deleted.'; exit 1; fi
bash testnet/scripts/stop-testnet.sh
hmc_data="${HMC_DATA_DIR:-$PWD/testnet/.data}"
# Wait for shutdown before moving validator signing state.
for i in $(seq 1 30); do if ! pgrep -f "hmcd start $hmc_data" >/dev/null; then break; fi; sleep 1; done
if pgrep -f "hmcd start $hmc_data" >/dev/null; then echo 'Validators still running; reset aborted.'; exit 1; fi
if [ -d "$hmc_data" ]; then mv "$hmc_data" "$hmc_data.backup.$(date +%s)"; fi
bash testnet/scripts/start-testnet.sh
