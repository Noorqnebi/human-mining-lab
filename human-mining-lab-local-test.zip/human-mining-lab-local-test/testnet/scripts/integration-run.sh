#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
export HMC_DATA_DIR="${HMC_DATA_DIR:-$PWD/testnet/.data-integration}"
if [ -d "$HMC_DATA_DIR" ]; then echo 'Integration data already exists; refusing to replace it.'; exit 1; fi
trap 'bash testnet/scripts/stop-testnet.sh' EXIT
bash testnet/scripts/start-testnet.sh
for i in $(seq 1 30); do if curl -fsS http://127.0.0.1:8788/state > /dev/null 2>&1; then break; fi; sleep 1; done
bash testnet/scripts/status-testnet.sh
node -e 'console.log("Node clock:",new Date().toISOString())'
node testnet/scripts/e2e.mjs
node testnet/scripts/check-chain.mjs
node testnet/scripts/adversarial.mjs
curl -fsS http://127.0.0.1:8788/state > "$HMC_DATA_DIR/verified-state.json"
