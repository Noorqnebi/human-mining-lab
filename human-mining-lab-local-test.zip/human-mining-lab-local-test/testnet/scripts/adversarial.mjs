// On-chain rejection tests with a legitimate test oracle key. Not shipped to browsers.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createPrivateKey,sign,createHash,randomUUID} from 'node:crypto';
const base=process.env.HMC_API||'http://127.0.0.1:8788',root=process.env.HMC_DATA_DIR||'testnet/.data';
const {state}=await (await fetch(base+'/state')).json();const original=state.transactions.find(t=>t.certificate)?.certificate;if(!original)throw Error('Complete a valid mining session first');
const key=createPrivateKey({key:Buffer.concat([Buffer.from('302e020100300506032b657004220420','hex'),Buffer.from(fs.readFileSync(path.join(root,'oracle.seed'),'utf8').trim(),'hex')]),format:'der',type:'pkcs8'});
const sha=v=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const cases=[['duplicate session',c=>{}],['duplicate proof',c=>{c.nonce=randomUUID()}],['wrong miner binding',c=>{c.work.minerAddress='hmc'+'b'.repeat(40)}],['wrong epoch',c=>{c.work.epochId+=4}],['expired proof',c=>{c.expiresAt=c.issuedAt}],['excessive work',c=>{c.work.humanUnits=3600000000000}],['malformed commitment',c=>{c.work.challengeChainRoot='bad'}],['wrong oracle signature',c=>{}],['modified HU after signing',c=>{}]];
for(const [name,change] of cases){const c=structuredClone(original);if(!name.startsWith('duplicate')){c.work.sessionId=randomUUID();c.nonce=randomUUID()}change(c);c.finalProofHash=sha(c.work);let tx={type:'MsgSubmitHumanMiningProof',certificate:c,signature:sign(null,Buffer.from(JSON.stringify(c)),key).toString('hex')};if(name==='wrong oracle signature')tx.signature='0'.repeat(128);if(name==='modified HU after signing')c.work.humanUnits++;
 const r=await fetch(base+'/broadcast',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(tx)});const v=await r.json();assert(!r.ok,name+' unexpectedly accepted');console.log('PASS on-chain rejection:',name,'→',v.error)}
