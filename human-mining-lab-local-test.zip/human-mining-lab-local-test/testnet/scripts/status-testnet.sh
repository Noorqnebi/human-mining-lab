#!/usr/bin/env bash
set -euo pipefail
for port in 26657 26667 26677; do curl -fsS --max-time 3 "http://127.0.0.1:$port/status" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{const r=JSON.parse(s).result;console.log(r.node_info.moniker,"height",r.sync_info.latest_block_height,"app hash",r.sync_info.latest_app_hash)})'; done
