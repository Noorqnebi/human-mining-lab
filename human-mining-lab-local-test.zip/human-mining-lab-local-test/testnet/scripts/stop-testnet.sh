#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
hmc_data="${HMC_DATA_DIR:-$PWD/testnet/.data}"
for name in oracle node0 node1 node2; do
 file="$hmc_data/$name.pid"
 if [ -f "$file" ]; then kill "$(cat "$file")" 2>/dev/null || true; rm "$file"; fi
done
printf 'Stop requested. Chain data and test wallets are retained.\n'
