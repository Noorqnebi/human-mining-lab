// Phase 1 local launcher: fresh keys on first run; preserve the selected ledger on restart.
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import {fileURLToPath} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
process.chdir(root);
const vite=path.join(root,'node_modules/vite/bin/vite.js');
const data=path.resolve(process.env.HMC_DATA_DIR||path.join(root,'testnet/.data'));
const required=fs.readFileSync(path.join(root,'testnet/go.mod'),'utf8').match(/^go ([\d.]+)/m)[1];
if(Number(process.versions.node.split('.')[0])<24)throw Error('Install Node 24 or newer before running this local package.');
if(!fs.existsSync(vite))throw Error('Run npm ci in the project directory first.');
if(!fs.existsSync(path.join(root,'testnet/bin/hmcd'))){
 const go=spawnSync('go',['version'],{encoding:'utf8',timeout:15000});
 const found=go.stdout?.match(/go(\d+\.\d+(?:\.\d+)?)/)?.[1];
 const version=s=>[0,1,2].reduce((n,i)=>n*1000+Number(s.split('.')[i]||0),0);
 if(go.status!==0||!found||version(found)<version(required))throw Error(`Install Go ${required} or newer (go.dev/dl), then reopen Terminal. The node is built locally on first start.`);
 console.log(`Go ${found}; first start will compile the native node for this computer.`);
}
for(const port of [4173,8788,26656,26657,26666,26667,26676,26677])await new Promise((resolve,reject)=>{
 const probe=net.createServer();probe.once('error',()=>reject(Error(`Local port ${port} is in use. Stop your previous local lab first; this launcher never kills unrelated processes.`)));probe.listen(port,'127.0.0.1',()=>probe.close(resolve));
});
console.log('Local HMC Lab — test coins only. Data: '+data);
if(process.argv.includes('--check')){console.log('PASS Node/dependencies/Go availability and local ports. This is not a compiler or mining acceptance test.');process.exit(0)}
const children=[];let stopping=false;
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function stop(code=0){if(stopping)return;stopping=true;for(const c of [...children].reverse()){try{process.kill(-c.pid,'SIGTERM')}catch{}}
 const until=Date.now()+15000;while(children.some(c=>c.exitCode===null&&c.signalCode===null)&&Date.now()<until)await delay(100);
 console.log('Local lab stopped. Chain data and encrypted browser wallets retained.');process.exitCode=code;
}
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{void stop()});
function launch(command,args,env){const c=spawn(command,args,{cwd:root,env,stdio:'inherit',detached:true});children.push(c);c.on('error',e=>{console.error(e.message);void stop(1)});c.on('exit',code=>{if(!stopping){console.error('A local service exited unexpectedly ('+code+').');void stop(1)}});return c}
async function waitFor(url,accept,timeout){const until=Date.now()+timeout;while(!stopping&&Date.now()<until){try{const r=await fetch(url,{signal:AbortSignal.timeout(2500)});if(r.ok&&await accept(r))return}catch{}await delay(500)}throw Error(stopping?'Startup stopped':`Service not ready: ${url}. Check ${data}/node*.log and oracle.log locally; do not share secret files.`)}
const env={...process.env,HMC_DATA_DIR:data,HMC_ORACLE_PORT:'8788',HMC_RPC:'http://127.0.0.1:26657',HMC_ALLOWED_ORIGINS:'http://localhost:4173,http://127.0.0.1:4173'};
try{
 launch('bash',['testnet/scripts/start-testnet.sh','--foreground'],env);
 console.log('Starting three validators and Oracle; first compilation may take several minutes…');
 await waitFor('http://127.0.0.1:8788/state',async r=>{const s=await r.json();return s.state?.height>0&&s.validators?.validators?.length===3},600000);
 for(const port of [26657,26667,26677])await waitFor(`http://127.0.0.1:${port}/status`,async r=>Number((await r.json()).result?.sync_info?.latest_block_height)>0,30000);
 launch(process.execPath,[vite,'--host','127.0.0.1','--port','4173','--strictPort'],{...env,HMC_LOCAL_TESTNET:'1',HMC_MANAGED_TESTNET:'1'});
 await waitFor('http://127.0.0.1:4173/',async r=>(await r.text()).includes('<html'),120000);
 await waitFor('http://127.0.0.1:4173/api/testnet/state',async r=>(await r.json()).state?.height>0,30000);
 console.log('\nREADY — http://localhost:4173\nFrontend + Oracle proxy + three CometBFT validators checked.\nCreate/unlock wallet, mine and submit in the UI. No more Terminal commands during the session. Ctrl+C stops all local services.');
}catch(e){if(!stopping)console.error(e.message);await stop(stopping?0:1)}
