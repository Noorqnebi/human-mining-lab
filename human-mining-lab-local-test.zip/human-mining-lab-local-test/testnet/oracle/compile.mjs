import fs from 'node:fs';
import ts from 'typescript';
const out=new URL('./generated/',import.meta.url);fs.mkdirSync(out,{recursive:true});
for(const name of ['geometry','catalog','model','sha256','attention','interaction','economics','proof','evidence']){
 const source=fs.readFileSync(new URL('../../lib/protocol/'+name+'.ts',import.meta.url),'utf8');
 fs.writeFileSync(new URL(name+'.mjs',out),ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText.replace(/from '(\.\/[^']+)'/g,"from '$1.mjs'"));
}
