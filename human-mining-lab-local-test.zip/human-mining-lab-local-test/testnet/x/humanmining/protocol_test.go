package humanmining

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	abci "github.com/cometbft/cometbft/abci/types"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func fixture() (*State, ed25519.PrivateKey, Tx, int64) {
	pub, key, _ := ed25519.GenerateKey(rand.Reader)
	s := NewState("hmc-private-1", hex.EncodeToString(pub), hex.EncodeToString(pub))
	at := int64(1800000060)
	s.Timestamp = at
	s.EpochAt(at)
	w := Work{Version, s.ChainID, "session-0123456789", Address(pub), Address(pub), at / 600, at - 600, at, 600000, 540000, 486000, 22, 20, 2, 9400, 9600, 9000, 1000000, strings.Repeat("a", 64)}
	c := Certificate{w, Hash(Bytes(w)), "nonce-0123456789abcdef", at, at + 180}
	tx := Tx{Type: "MsgSubmitHumanMiningProof", Certificate: &c}
	sign(&tx, key)
	return s, key, tx, at
}
func sign(tx *Tx, key ed25519.PrivateKey) {
	var v any = tx.Certificate
	if tx.Transfer != nil {
		v = tx.Transfer
	}
	if tx.Admin != nil {
		v = tx.Admin
	}
	tx.Signature = hex.EncodeToString(ed25519.Sign(key, Bytes(v)))
}
func TestValidation(t *testing.T) {
	cases := []struct {
		name   string
		mutate func(*State, *Tx, int64)
	}{
		{"modified HU", func(s *State, x *Tx, at int64) { x.Certificate.Work.HumanUnits++ }},
		{"modified miner", func(s *State, x *Tx, at int64) { x.Certificate.Work.MinerAddress = "hmc" + strings.Repeat("b", 40) }},
		{"wrong oracle", func(s *State, x *Tx, at int64) { x.Signature = strings.Repeat("0", 128) }},
		{"expired", func(s *State, x *Tx, at int64) { x.Certificate.ExpiresAt = at }},
		{"wrong epoch", func(s *State, x *Tx, at int64) { x.Certificate.Work.EpochID++ }},
		{"malformed proof", func(s *State, x *Tx, at int64) { x.Certificate.Work.ChallengeChainRoot = "broken" }},
		{"reward cap", func(s *State, x *Tx, at int64) { s.Epochs[at/600].Params.MaxReward = 1 }},
		{"epoch cap", func(s *State, x *Tx, at int64) { s.Epochs[at/600].Params.EpochCap = 1 }},
		{"day cap", func(s *State, x *Tx, at int64) { s.Params.DayCap = 1 }},
		{"max supply", func(s *State, x *Tx, at int64) { s.Params.MaxSupply = 1 }},
		{"paused", func(s *State, x *Tx, at int64) { s.Params.Paused = true }},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			s, _, x, at := fixture()
			tc.mutate(s, &x, at)
			if _, e := s.Apply(Bytes(x), at, 1); e == nil {
				t.Fatal("expected rejection")
			}
			if s.Supply != 0 {
				t.Fatal("invalid proof minted")
			}
		})
	}
}
func TestNativeMintTransferReplay(t *testing.T) {
	s, key, x, at := fixture()
	r, e := s.Apply(Bytes(x), at, 1)
	if e != nil {
		t.Fatal(e)
	}
	if r.Amount != 4860000 || s.Supply != r.Amount {
		t.Fatal("incorrect deterministic reward")
	}
	if _, e = s.Apply(Bytes(x), at, 2); e == nil || !strings.Contains(e.Error(), "already claimed") {
		t.Fatal("replay accepted")
	}
	for _, change := range []func(*Certificate){func(c *Certificate) { c.Nonce += "a" }, func(c *Certificate) { c.Work.SessionID += "a"; c.FinalProofHash = Hash(Bytes(c.Work)) }} {
		y := x
		c := *x.Certificate
		y.Certificate = &c
		change(&c)
		sign(&y, key)
		if _, e = s.Apply(Bytes(y), at, 2); e == nil {
			t.Fatal("reused identifier accepted")
		}
	}
	pub2, _, _ := ed25519.GenerateKey(rand.Reader)
	from := x.Certificate.Work.MinerAddress
	to := Address(pub2)
	tr := Tx{Type: "MsgSend", Transfer: &Transfer{s.ChainID, from, to, 1000000, 1}, PublicKey: hex.EncodeToString(key.Public().(ed25519.PublicKey))}
	sign(&tr, key)
	if _, e = s.Apply(Bytes(tr), at, 2); e != nil {
		t.Fatal(e)
	}
	if s.Balances[to] != 1000000 || s.Balances[from] != 3860000 || s.Supply != 4860000 {
		t.Fatal("native transfer balances invalid")
	}
	if _, e = s.Apply(Bytes(tr), at, 3); e == nil {
		t.Fatal("transfer replay accepted")
	}
}
func TestABCICommitPersistence(t *testing.T) {
	s, _, x, at := fixture()
	file := filepath.Join(t.TempDir(), "state.json")
	a, _ := Open(file)
	a.state = s
	ctx := context.Background()
	r, e := a.FinalizeBlock(ctx, &abci.RequestFinalizeBlock{Height: 1, Time: time.Unix(at, 0), Txs: [][]byte{Bytes(x), Bytes(x)}})
	if e != nil || r.TxResults[0].Code != 0 || r.TxResults[1].Code == 0 {
		t.Fatal("block replay validation failed")
	}
	if _, e = a.Commit(ctx, &abci.RequestCommit{}); e != nil {
		t.Fatal(e)
	}
	b, e := Open(file)
	if e != nil || len(b.state.Transactions) != 1 || b.state.Supply != 4860000 || b.state.Rejected != 1 {
		t.Fatal("history did not persist")
	}
	if Hash(Bytes(b.state)) != Hash(Bytes(a.state)) {
		t.Fatal("restart app hash differs")
	}
}
func TestAdminEpoch(t *testing.T) {
	s, key, _, at := fixture()
	p := s.Params
	p.Difficulty = 1200000
	x := Tx{Type: "MsgUpdateParameters", Admin: &Admin{s.ChainID, 1, at/600 + 1, p}}
	sign(&x, key)
	if _, e := s.Apply(Bytes(x), at, 1); e != nil {
		t.Fatal(e)
	}
	if s.Params.Difficulty != 1000000 {
		t.Fatal("early parameter change")
	}
	s.EpochAt(at + 600)
	if s.Params.Difficulty != 1200000 || len(s.DifficultyHistory) != 1 {
		t.Fatal("parameter change missing")
	}
}

func TestCorruptLedgerFailsClosed(t *testing.T) {
	for _, raw := range []string{"null", "{}", "{broken"} {
		file := filepath.Join(t.TempDir(), "state.json")
		os.WriteFile(file, []byte(raw), 0600)
		if _, err := Open(file); err == nil {
			t.Fatal("corrupt database accepted")
		}
	}
	s, _, _, _ := fixture()
	s.Supply = 10
	file := filepath.Join(t.TempDir(), "state.json")
	os.WriteFile(file, Bytes(s), 0600)
	if _, err := Open(file); err == nil {
		t.Fatal("inconsistent supply accepted")
	}
}
