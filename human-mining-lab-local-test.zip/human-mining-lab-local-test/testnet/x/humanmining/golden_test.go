package humanmining

import (
	"encoding/json"
	"os"
	"testing"
)

func TestGoldenCertificate(t *testing.T) {
	raw, e := os.ReadFile("../../testdata/hmp-0.1-golden.json")
	if e != nil {
		t.Fatal(e)
	}
	var v struct {
		OraclePublicKey  string      `json:"oraclePublicKey"`
		WorkBytes        string      `json:"workBytes"`
		CertificateBytes string      `json:"certificateBytes"`
		FinalProofHash   string      `json:"finalProofHash"`
		Signature        string      `json:"signature"`
		ExpectedReward   int64       `json:"expectedRewardUhmc"`
		Certificate      Certificate `json:"certificate"`
	}
	if e = json.Unmarshal(raw, &v); e != nil {
		t.Fatal(e)
	}
	if string(Bytes(v.Certificate.Work)) != v.WorkBytes || string(Bytes(v.Certificate)) != v.CertificateBytes || Hash(Bytes(v.Certificate.Work)) != v.FinalProofHash {
		t.Fatal("canonical certificate compatibility changed")
	}
	s := NewState("hmc-private-1", v.OraclePublicKey, v.OraclePublicKey)
	at := v.Certificate.IssuedAt
	s.Timestamp = at
	s.EpochAt(at)
	receipt, e := s.Apply(Bytes(Tx{Type: "MsgSubmitHumanMiningProof", Certificate: &v.Certificate, Signature: v.Signature}), at, 1)
	if e != nil || receipt.Amount != v.ExpectedReward {
		t.Fatalf("legacy golden mint mismatch: %v %+v", e, receipt)
	}
}
