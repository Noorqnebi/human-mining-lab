// Package humanmining implements native issuance for a CometBFT ABCI sovereign
// test chain. It is deliberately not an ERC-20, nor a Cosmos SDK bank module.
package humanmining

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"regexp"
)

const Version = "HMP/0.1"
const Denom = "uhmc"

type Work struct {
	ProtocolVersion      string `json:"protocolVersion"`
	ChainID              string `json:"chainId"`
	SessionID            string `json:"sessionId"`
	MinerAddress         string `json:"minerAddress"`
	MinerID              string `json:"minerId"`
	EpochID              int64  `json:"epochId"`
	StartedAt            int64  `json:"startedAt"`
	CompletedAt          int64  `json:"completedAt"`
	SessionDuration      int64  `json:"sessionDuration"`
	VerifiedHumanTime    int64  `json:"verifiedHumanTime"` // milliseconds
	HumanUnits           int64  `json:"humanUnits"`        // milli-HU
	ChallengeCount       int64  `json:"challengeCount"`
	SuccessfulChallenges int64  `json:"successfulChallenges"`
	MissedChallenges     int64  `json:"missedChallenges"`
	AttentionScore       int64  `json:"attentionScore"` // basis points
	ReliabilityScore     int64  `json:"reliabilityScore"`
	MiningEfficiency     int64  `json:"miningEfficiency"`
	Difficulty           int64  `json:"difficulty"` // millionths
	ChallengeChainRoot   string `json:"challengeChainRoot"`
}
type Certificate struct {
	Work           Work   `json:"work"`
	FinalProofHash string `json:"finalProofHash"`
	Nonce          string `json:"nonce"`
	IssuedAt       int64  `json:"issuedAt"`
	ExpiresAt      int64  `json:"expiresAt"`
}
type Transfer struct {
	ChainID string `json:"chainId"`
	From    string `json:"from"`
	To      string `json:"to"`
	Amount  int64  `json:"amount"`
	Nonce   int64  `json:"nonce"`
}
type Params struct {
	Difficulty      int64  `json:"difficulty"`
	EpochSeconds    int64  `json:"epochSeconds"`
	EpochRewardPool int64  `json:"epochRewardPool"`
	ReferenceHU     int64  `json:"referenceHU"`
	EpochCap        int64  `json:"epochCap"`
	DayCap          int64  `json:"dayCap"`
	MaxReward       int64  `json:"maxReward"`
	MaxSupply       int64  `json:"maxSupply"`
	MinHU           int64  `json:"minHU"`
	MaxHU           int64  `json:"maxHU"`
	ProofExpiry     int64  `json:"proofExpiry"`
	OraclePublicKey string `json:"oraclePublicKey"`
	Paused          bool   `json:"paused"`
}
type Admin struct {
	ChainID        string `json:"chainId"`
	Nonce          int64  `json:"nonce"`
	EffectiveEpoch int64  `json:"effectiveEpoch"`
	Params         Params `json:"params"`
}
type Tx struct {
	Type        string       `json:"type"`
	Certificate *Certificate `json:"certificate,omitempty"`
	Transfer    *Transfer    `json:"transfer,omitempty"`
	Admin       *Admin       `json:"admin,omitempty"`
	PublicKey   string       `json:"publicKey,omitempty"`
	Signature   string       `json:"signature"`
}
type Receipt struct {
	Hash            string       `json:"hash"`
	Type            string       `json:"type"`
	Height          int64        `json:"height"`
	Timestamp       int64        `json:"timestamp"`
	Miner           string       `json:"miner"`
	To              string       `json:"to,omitempty"`
	Amount          int64        `json:"amount"`
	Certificate     *Certificate `json:"certificate,omitempty"`
	OracleSignature string       `json:"oracleSignature,omitempty"`
}
type Epoch struct {
	ID      int64           `json:"id"`
	Params  Params          `json:"params"`
	TotalHU int64           `json:"totalHU"`
	Minted  int64           `json:"minted"`
	Proofs  int64           `json:"proofs"`
	Miners  map[string]bool `json:"miners"`
}
type State struct {
	ChainID           string           `json:"chainId"`
	Height            int64            `json:"height"`
	Timestamp         int64            `json:"timestamp"`
	Params            Params           `json:"params"`
	AdminPublicKey    string           `json:"adminPublicKey"`
	AdminNonce        int64            `json:"adminNonce"`
	Pending           *Admin           `json:"pending,omitempty"`
	DifficultyHistory []Admin          `json:"difficultyHistory"`
	Supply            int64            `json:"supply"`
	Balances          map[string]int64 `json:"balances"`
	Nonces            map[string]int64 `json:"nonces"`
	UsedSessions      map[string]bool  `json:"usedSessions"`
	UsedProofs        map[string]bool  `json:"usedProofs"`
	UsedNonces        map[string]bool  `json:"usedNonces"`
	Epochs            map[int64]*Epoch `json:"epochs"`
	Daily             map[int64]int64  `json:"daily"`
	Transactions      []Receipt        `json:"transactions"`
	Rejected          int64            `json:"rejected"`
}

func DefaultParams(oracle string) Params {
	return Params{Difficulty: 1000000, EpochSeconds: 600, EpochRewardPool: 10000000, ReferenceHU: 1000000, EpochCap: 100000000, DayCap: 1000000000, MaxReward: 10000000, MaxSupply: 1000000000000000, MinHU: 1000, MaxHU: 3600000, ProofExpiry: 180, OraclePublicKey: oracle}
}
func NewState(chain, oracle, admin string) *State {
	return &State{ChainID: chain, Params: DefaultParams(oracle), AdminPublicKey: admin, Balances: map[string]int64{}, Nonces: map[string]int64{}, UsedSessions: map[string]bool{}, UsedProofs: map[string]bool{}, UsedNonces: map[string]bool{}, Epochs: map[int64]*Epoch{}, Daily: map[int64]int64{}, Transactions: []Receipt{}, DifficultyHistory: []Admin{}}
}
func Bytes(v any) []byte {
	b, e := json.Marshal(v)
	if e != nil {
		panic(e)
	}
	return b
}
func Hash(b []byte) string      { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }
func Address(pub []byte) string { return "hmc" + Hash(pub)[:40] }

var hashRE = regexp.MustCompile(`^[0-9a-f]{64}$`)
var addressRE = regexp.MustCompile(`^hmc[0-9a-f]{40}$`)

func Decode(b []byte) (Tx, error) {
	var t Tx
	if len(b) > 32768 {
		return t, errors.New("transaction too large")
	}
	d := json.NewDecoder(bytes.NewReader(b))
	d.DisallowUnknownFields()
	if e := d.Decode(&t); e != nil {
		return t, e
	}
	if !bytes.Equal(Bytes(t), b) {
		return t, errors.New("non-canonical transaction")
	}
	return t, nil
}
func signature(pub, sig string, v any) bool {
	p, e := hex.DecodeString(pub)
	s, f := hex.DecodeString(sig)
	return e == nil && f == nil && len(p) == 32 && len(s) == 64 && ed25519.Verify(p, Bytes(v), s)
}
func ValidateParams(p Params) error {
	if p.Difficulty < 100000 || p.Difficulty > 100000000 || p.EpochSeconds != 600 || p.EpochRewardPool < 1 || p.EpochRewardPool > 1000000000000 || p.ReferenceHU < 1 || p.ReferenceHU > 1000000000000 || p.EpochCap < 1 || p.DayCap < p.EpochCap || p.MaxReward < 1 || p.MaxReward > p.EpochCap || p.MaxSupply < 1 || p.MaxSupply > 1000000000000000 || p.DayCap > p.MaxSupply || p.MinHU < 1 || p.MaxHU < p.MinHU || p.MaxHU > 3600000 || p.ProofExpiry < 10 || p.ProofExpiry > 600 || !hashRE.MatchString(p.OraclePublicKey) {
		return errors.New("invalid protocol parameters")
	}
	return nil
}
func (s *State) EpochAt(at int64) *Epoch {
	id := at / s.Params.EpochSeconds
	if s.Pending != nil && id >= s.Pending.EffectiveEpoch {
		s.Params = s.Pending.Params
		s.DifficultyHistory = append(s.DifficultyHistory, *s.Pending)
		s.Pending = nil
	}
	e := s.Epochs[id]
	if e == nil {
		e = &Epoch{ID: id, Params: s.Params, Miners: map[string]bool{}}
		s.Epochs[id] = e
	}
	return e
}
func Reward(hu int64, p Params) (int64, error) {
	n := big.NewInt(hu)
	n.Mul(n, big.NewInt(p.EpochRewardPool))
	n.Mul(n, big.NewInt(1000000))
	d := new(big.Int).Mul(big.NewInt(p.ReferenceHU), big.NewInt(p.Difficulty))
	if d.Sign() <= 0 {
		return 0, errors.New("invalid reward divisor")
	}
	n.Div(n, d)
	if !n.IsInt64() {
		return 0, errors.New("reward overflow")
	}
	return n.Int64(), nil
}
func (s *State) Apply(raw []byte, at, height int64) (Receipt, error) {
	t, err := Decode(raw)
	r := Receipt{Hash: Hash(raw), Type: t.Type, Height: height, Timestamp: at}
	if err != nil {
		return r, err
	}
	s.EpochAt(at)
	switch t.Type {
	case "MsgSubmitHumanMiningProof":
		if t.Certificate == nil || t.Transfer != nil || t.Admin != nil || t.PublicKey != "" {
			return r, errors.New("malformed mining message")
		}
		c := t.Certificate
		w := c.Work
		p := s.Params
		if p.Paused {
			return r, errors.New("human mining submissions paused")
		}
		if w.ProtocolVersion != Version || w.ChainID != s.ChainID || !addressRE.MatchString(w.MinerAddress) || w.MinerID != w.MinerAddress || len(w.SessionID) < 16 || len(w.SessionID) > 128 || len(c.Nonce) < 16 || len(c.Nonce) > 128 {
			return r, errors.New("invalid proof identity")
		}
		if !hashRE.MatchString(w.ChallengeChainRoot) || !hashRE.MatchString(c.FinalProofHash) || Hash(Bytes(w)) != c.FinalProofHash {
			return r, errors.New("invalid proof commitment")
		}
		if s.UsedSessions[w.SessionID] || s.UsedProofs[c.FinalProofHash] || s.UsedNonces[c.Nonce] {
			return r, errors.New("Mining proof already claimed")
		}
		if w.EpochID != w.CompletedAt/p.EpochSeconds || w.EpochID > at/p.EpochSeconds || w.EpochID < at/p.EpochSeconds-1 {
			return r, errors.New("wrong epoch")
		}
		ep := s.Epochs[w.EpochID]
		if ep == nil {
			return r, errors.New("unknown epoch")
		}
		p = ep.Params
		if c.IssuedAt > w.CompletedAt+30 || c.IssuedAt < w.CompletedAt || c.IssuedAt > at || c.ExpiresAt <= at || c.ExpiresAt <= c.IssuedAt || c.ExpiresAt-c.IssuedAt > p.ProofExpiry {
			return r, errors.New("expired or invalid certificate time")
		}
		if !signature(p.OraclePublicKey, t.Signature, c) {
			return r, errors.New("invalid oracle signature")
		}
		if w.StartedAt <= 0 || w.CompletedAt > w.StartedAt+3602 || w.CompletedAt-w.StartedAt < 600 || w.SessionDuration != (w.CompletedAt-w.StartedAt)*1000 || w.VerifiedHumanTime < 0 || w.VerifiedHumanTime > w.SessionDuration || w.AttentionScore < 0 || w.AttentionScore > 10000 || w.ReliabilityScore < 0 || w.ReliabilityScore > 10000 || w.MiningEfficiency < 0 || w.MiningEfficiency > 10000 || w.Difficulty != p.Difficulty {
			return r, errors.New("invalid work parameters")
		}
		// Baseline production rate is one HU per verified second, scaled by efficiency.
		expected := w.VerifiedHumanTime * w.MiningEfficiency / 10000
		if w.HumanUnits != expected || w.HumanUnits < p.MinHU || w.HumanUnits > p.MaxHU || w.ChallengeCount < 10 || w.ChallengeCount > 240 || w.SuccessfulChallenges < 1 || w.MissedChallenges < 0 || w.SuccessfulChallenges+w.MissedChallenges > w.ChallengeCount {
			return r, errors.New("invalid human work")
		}
		amount, e := Reward(w.HumanUnits, p)
		if e != nil {
			return r, e
		}
		day := at / 86400
		if amount < 1 || amount > p.MaxReward {
			return r, errors.New("maximum reward per proof exceeded")
		}
		if amount > p.EpochCap-ep.Minted {
			return r, errors.New("epoch mint cap exceeded")
		}
		if amount > s.Params.DayCap-s.Daily[day] {
			return r, errors.New("daily mint cap exceeded")
		}
		if amount > s.Params.MaxSupply-s.Supply {
			return r, errors.New("max supply exceeded")
		}
		s.Balances[w.MinerAddress] += amount
		s.Supply += amount
		s.Daily[day] += amount
		ep.Minted += amount
		ep.TotalHU += w.HumanUnits
		ep.Proofs++
		ep.Miners[w.MinerAddress] = true
		s.UsedSessions[w.SessionID] = true
		s.UsedProofs[c.FinalProofHash] = true
		s.UsedNonces[c.Nonce] = true
		r.Miner = w.MinerAddress
		r.Amount = amount
		r.Certificate = c
		r.OracleSignature = t.Signature
	case "MsgSend":
		if t.Transfer == nil || t.Certificate != nil || t.Admin != nil {
			return r, errors.New("malformed transfer")
		}
		v := t.Transfer
		pub, e := hex.DecodeString(t.PublicKey)
		if e != nil || v.ChainID != s.ChainID || v.From != Address(pub) || !addressRE.MatchString(v.To) || v.Amount <= 0 || v.Nonce != s.Nonces[v.From]+1 || !signature(t.PublicKey, t.Signature, v) {
			return r, errors.New("invalid signed transfer")
		}
		if s.Balances[v.From] < v.Amount {
			return r, errors.New("insufficient native balance")
		}
		s.Balances[v.From] -= v.Amount
		s.Balances[v.To] += v.Amount
		s.Nonces[v.From] = v.Nonce
		r.Miner = v.From
		r.To = v.To
		r.Amount = v.Amount
	case "MsgUpdateParameters":
		if t.Admin == nil || t.Transfer != nil || t.Certificate != nil || t.PublicKey != "" {
			return r, errors.New("malformed admin message")
		}
		v := t.Admin
		if v.ChainID != s.ChainID || v.Nonce != s.AdminNonce+1 || v.EffectiveEpoch != at/s.Params.EpochSeconds+1 || s.Pending != nil || !signature(s.AdminPublicKey, t.Signature, v) {
			return r, errors.New("unauthorized parameter update")
		}
		if e := ValidateParams(v.Params); e != nil {
			return r, e
		}
		if v.Params.MaxSupply < s.Supply {
			return r, errors.New("max supply below current supply")
		}
		s.Pending = v
		s.AdminNonce = v.Nonce
	default:
		return r, fmt.Errorf("unknown message %q", t.Type)
	}
	s.Transactions = append(s.Transactions, r)
	return r, nil
}
func Clone(s *State) *State {
	var n State
	if err := json.Unmarshal(Bytes(s), &n); err != nil {
		panic(err)
	}
	return &n
}
