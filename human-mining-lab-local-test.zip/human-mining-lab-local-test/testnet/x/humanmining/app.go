package humanmining

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	abci "github.com/cometbft/cometbft/abci/types"
	"os"
	"path/filepath"
	"sync"
)

type Application struct {
	abci.BaseApplication
	mu             sync.Mutex
	state, pending *State
	file           string
}

func Open(file string) (*Application, error) {
	a := &Application{file: file}
	b, e := os.ReadFile(file)
	if e == nil {
		e = json.Unmarshal(b, &a.state)
		if e == nil {
			e = validateStoredState(a.state)
		}
	} else if os.IsNotExist(e) {
		e = nil
	}
	return a, e
}
func (a *Application) Info(context.Context, *abci.RequestInfo) (*abci.ResponseInfo, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	r := &abci.ResponseInfo{Data: "HMC Private Testnet · CometBFT ABCI · HMP/0.1", AppVersion: 1}
	if a.state != nil {
		r.LastBlockHeight = a.state.Height
		r.LastBlockAppHash = digest(a.state)
	}
	return r, nil
}
func digest(s *State) []byte { b, _ := hex.DecodeString(Hash(Bytes(s))); return b }
func (a *Application) InitChain(_ context.Context, r *abci.RequestInitChain) (*abci.ResponseInitChain, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	var s State
	if e := json.Unmarshal(r.AppStateBytes, &s); e != nil {
		return nil, e
	}
	if e := ValidateParams(s.Params); e != nil {
		return nil, e
	}
	a.state = &s
	a.pending = &s
	return &abci.ResponseInitChain{AppHash: digest(&s)}, nil
}
func (a *Application) CheckTx(_ context.Context, r *abci.RequestCheckTx) (*abci.ResponseCheckTx, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := Clone(a.state)
	_, e := s.Apply(r.Tx, s.Timestamp, s.Height+1)
	if e != nil {
		return &abci.ResponseCheckTx{Code: 1, Log: e.Error()}, nil
	}
	return &abci.ResponseCheckTx{}, nil
}
func (a *Application) FinalizeBlock(_ context.Context, r *abci.RequestFinalizeBlock) (*abci.ResponseFinalizeBlock, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := Clone(a.state)
	s.Height = r.Height
	s.Timestamp = r.Time.Unix()
	s.EpochAt(s.Timestamp)
	out := &abci.ResponseFinalizeBlock{}
	for _, raw := range r.Txs {
		next := Clone(s)
		receipt, e := next.Apply(raw, s.Timestamp, s.Height)
		result := &abci.ExecTxResult{}
		if e != nil {
			s.Rejected++
			result.Code = 1
			result.Log = e.Error()
		} else {
			s = next
			result.Data = Bytes(receipt)
		}
		out.TxResults = append(out.TxResults, result)
	}
	a.pending = s
	out.AppHash = digest(s)
	return out, nil
}
func (a *Application) Commit(context.Context, *abci.RequestCommit) (*abci.ResponseCommit, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.pending != nil {
		if e := os.MkdirAll(filepath.Dir(a.file), 0700); e != nil {
			return nil, e
		}
		f, e := os.OpenFile(a.file+".tmp", os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
		if e != nil {
			return nil, e
		}
		_, e = f.Write(Bytes(a.pending))
		if e == nil {
			e = f.Sync()
		}
		f.Close()
		if e != nil {
			return nil, e
		}
		if e = os.Rename(a.file+".tmp", a.file); e != nil {
			return nil, e
		}
		a.state = a.pending
		a.pending = nil
	}
	return &abci.ResponseCommit{}, nil
}
func (a *Application) Query(_ context.Context, r *abci.RequestQuery) (*abci.ResponseQuery, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.state == nil {
		return &abci.ResponseQuery{Code: 1, Log: "chain starting"}, nil
	}
	if r.Path != "/state" {
		return &abci.ResponseQuery{Code: 1, Log: "unknown query"}, nil
	}
	return &abci.ResponseQuery{Value: Bytes(a.state), Height: a.state.Height}, nil
}

// Fail closed on incomplete or structurally inconsistent local ledgers.
// This is not a substitute for authenticated backups or CometBFT replay checks.
func validateStoredState(s *State) error {
	if s == nil || s.Balances == nil || s.Nonces == nil || s.UsedSessions == nil || s.UsedProofs == nil || s.UsedNonces == nil || s.Epochs == nil || s.Daily == nil || s.Supply < 0 || s.Supply > 1000000000000000 {
		return errors.New("corrupt or incomplete local chain state")
	}
	if err := ValidateParams(s.Params); err != nil {
		return err
	}
	var total int64
	for address, balance := range s.Balances {
		if !addressRE.MatchString(address) || balance < 0 || balance > s.Supply-total {
			return errors.New("invalid persisted balance")
		}
		total += balance
	}
	if total != s.Supply {
		return errors.New("persisted supply differs from balances")
	}
	return nil
}
