# Validation — 7 September 2026

## Actual execution

- Built Go node against pinned CometBFT v0.38.17; three independent validators initialized with zero supply and distinct keys.
- A real-time API session ran for 600 seconds using the existing challenge engine. Interactions were scripted, not supplied by a human and not played through the browser.
- Session `b9855db7-f351-4357-9ade-a8809724ef6e`: 23 generated/resolved challenges; final in-progress challenge ended unsuccessfully at the session boundary; VHT 583.442 seconds; efficiency 97.3155%; certificate work 567.747 HU after integer quantization.
- Initial submission failed because certificate issue time was newer than the latest committed block time. This was a real failure, not a passed E2E. The submission path now waits for the chain timestamp before broadcasting; the test client also retries that specific freshness race.
- The **same genuine completed-session certificate** was submitted after restarting the persisted network. It minted **5.67747 HMC-Test**, confirmed at **height 259**, epoch **2981252**.
- Mining tx: `D25BBDC202BB02F3A165F6FB51EFC3D7C72778D70262C993297DA99749D86C7F`.
- Explorer RPC returned that transaction and its block; all three nodes returned the same block hash at height 259. Restarting again retained that receipt and balance; agreement was also checked at height 260.
- Real-network rejection cases passed: duplicate session/transaction, duplicate proof, changed miner binding, wrong epoch, expiry, excessive HU, malformed commitment, wrong oracle signature, and HU modified after signing. Exact duplicate bytes can be rejected by CometBFT's transaction cache; a changed nonce with a reused proof reaches module replay protection.
- A **separate, explicitly synthetic protocol fixture**, signed by the test oracle, funded a newly generated test key for native-transfer validation. This fixture is not a second human session. A native transfer of **1 HMC-Test** confirmed at **height 262**, tx `2ADCA8F6F98A8824A226680299D665E0765C407A47279EA963DDAE76E2F1CD28`. Sender/recipient balances updated, supply stayed unchanged, and replay was rejected.

The tested integration network was stopped cleanly afterwards. Its ledger remains in the local test data directory. It is not a lasting service reachable by the user's deployed site. Genesis/runtime private keys are not part of committed source or the Site build.

## Full real-time API rerun — passed

After the timing fix, a fresh zero-supply network completed the entire script in one uninterrupted run:

- Session: `9d3fd07e-3e9c-4891-8fd7-c0e148a6af45`.
- Duration: 600 seconds; 22 successful challenges.
- VHT: 599.986 seconds; efficiency: 99.9941%; integer certificate work: 599.925 HU.
- Native mint: **5.99925 HMC-Test**; block **261**, epoch **2981296**.
- Transaction: `52E4DD43C8F1BB04DF0BAA931A07F5B86166136D30C188CE215A8EF208DDFD14`.
- Replay rejected, then a native transfer from this same session's test wallet succeeded. Both balances updated and explorer history contained the mint.
- All three validator nodes agreed on the same block at height 262; explorer block/transaction linkage and nine rejection cases passed again.
- No manual certificate recovery was needed in this rerun. Inputs were still scripted API evidence, not a human/browser test. The fresh network was stopped cleanly after testing.

Additional Oracle concurrency regressions passed with an explicitly stubbed RPC: delayed transaction confirmation does not stall another session's pulse, simultaneous duplicate start authorizations result in one acceptance, and uploaded HU cannot sign an unfinished session. These unit checks are separate from real blockchain evidence above.

## Automated checks passed

- Go `x/humanmining` tests: native mint and transfer, deterministic reward, signature/address/epoch/time/commitment validation, replay identifiers, per-proof/epoch/day/max-supply caps, admin next-epoch application, ABCI commit/restart persistence.
- Existing protocol suite: challenge cadence and sixteen continuous variants, strict response boundary, background VHT, smooth miss penalty, Founder attention settings, reward/history/proof compatibility. Floating comparison changed to a numerical tolerance; challenge mechanics were not changed.
- Test wallet cryptography: encrypted backup, nonextractable unlocked key, valid Ed25519 signing, wrong passphrase rejection and ciphertext/message tamper rejection.
- Frontend TypeScript and production build.

## Browser checks and unpassed acceptance criteria

The existing Lab rendered in the supervised browser. HMC Testnet and Mine → HMC Private Testnet rendered inside the original navigation and design. With no configured lasting upstream, the UI showed **Disconnected**, displayed no invented native balance and disabled Start Mining. Wallet create/unlock and encrypted backup controls were present. The old Simulation mode remained available.

**Not passed:** browser Start Mining → completed interaction session → native wallet confirmation end-to-end. The initial real-time API run also did not pass uninterrupted: its certificate required recovery after the timing failure. The repaired full 600-second API script subsequently passed end-to-end as recorded above. Individual real mint, persisted recovery, native transfer and actual-node rejection checks did pass as described above.

**Not solved:** independent validation of browser-reported quality/attention; lasting HTTPS infrastructure; full Cosmos SDK integration; distributed validator operators; complete in-browser Founder signing UI (reviewable change requests and operator CLI are implemented); all requested research metrics; public/mainnet readiness. These are material limitations, not cosmetic follow-ups.
