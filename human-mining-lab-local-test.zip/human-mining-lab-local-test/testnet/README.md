# HMC Private Testnet — HMP/0.1

This directory extends the existing Human Mining Lab repository. It does not replace the Lab, its simulation ledger, challenge engine, or historical proofs. Test coins have no monetary value. There are no public-chain contracts, mainnet connections, liquidity, trading or automatic migration of old HMC.

For the latest local-only acceptance steps and unresolved gates, see [LOCAL-ACCEPTANCE.ar.md](LOCAL-ACCEPTANCE.ar.md).

## Implementation status and stack

The node is a **real CometBFT v0.38.17 ABCI application**, written in Go, with three separate validator processes and independent validator keys/databases. `x/humanmining` owns native balances, issuance and protocol state. HMC-Test is the chain's native coin (`uhmc`), not ERC-20/SPL or a token contract.

**This implementation does not use the Cosmos SDK BaseApp/bank/module framework.** It is a smaller custom ABCI application. Cosmos SDK remains the requested preferred architecture, and this divergence should not be mistaken for a completed Cosmos SDK implementation. The existing Sites Worker cannot host persistent Go validators or a TCP peer network; that hosting constraint also applies to Cosmos SDK and does not establish that Cosmos SDK itself is unsuitable. A full SDK migration and standard wallet/address support remain open decisions.

The testnet is run locally during validation. Sites hosts the UI only. A lasting HTTPS oracle/validator host has not been provisioned. The UI displays **Disconnected** and no invented balance when that service is absent. Passing API integration does not establish that the user's deployed-site browser flow has passed.

## Architecture

- Existing React `Challenge` renderer: unchanged interactions plus an optional live evidence callback.
- Oracle Node service: imports a compiled copy of the existing protocol engine, issues server-owned sessions/challenges, checks four-second starts, measures receipt-time liveness, derives VHT, HU and efficiency, and checks the sequential SHA-256 chain.
- Certificate generator: integer work fields, a deterministic SHA-256 commitment, nonce, expiry and HMP/0.1 version.
- Attestation signer: Ed25519 private key, server environment or permission-restricted local seed file; never in client assets.
- CometBFT RPC: signed transaction submission and actual block confirmation.
- `x/humanmining`: deterministic validation, replay protection, reward calculation, emission caps and native ledger.
- Existing Lab: Testnet mining mode, encrypted test wallet, explorer, research and Founder status.

CometBFT creates/finalizes blocks. Human Mining controls **issuance**, not consensus.

## Critical trust limitation

**Verification Mode: Trusted Oracle – Prototype.** The oracle does not accept a browser's final HU, reward, session duration or final certificate. It generates the challenges and calculates these values itself. Uploaded old simulation sessions cannot be submitted for minting.

The renderer now reports nonce-bound raw coordinates, choices, gestures and hold edges. The Oracle grades them using its own receipt clock and issued target state. Client final grades, scores, HU, timestamps and rewards are rejected. The regression driver deliberately demonstrates that a scripted client can still manufacture valid raw inputs. Raw evidence raises the bar against direct score editing, but does not establish humanity or anti-bot security.

The trusted oracle can still lie about work. Chain validation limits its issuance, but does not solve this trust problem. Browser visibility signals are also forgeable. VHT stops on reported loss of focus; an absent connection loses its receipt-time lease within one second. This cannot establish physical attention.

## Run locally

Requirements: Go 1.27.1 (the verified toolchain; `go.mod` pins its version), Node 24, installed frontend dependencies, free local ports 26656–26677 and 8788. Linux/macOS shell scripts are supplied. Go dependencies are pinned by `go.mod` / `go.sum`.

From the repository root:

```bash
bash testnet/scripts/start-testnet.sh
bash testnet/scripts/status-testnet.sh
bash testnet/scripts/stop-testnet.sh
```

The first start builds `testnet/bin/hmcd`, initializes three validators and zero circulating supply, generates fresh oracle/admin keys, and starts the oracle. Use `start-testnet.sh --foreground` in environments that require a retained foreground process. Data is under `testnet/.data`; restart preserves balances, blocks, used proof IDs and signing state. Never run two processes using the same validator's signing files.

A dedicated integration harness starts its network and test client in one process environment:

```bash
bash testnet/scripts/integration-run.sh
```

It refuses to overwrite an existing `testnet/.data-integration` directory. This is intentional. Do not delete an existing environment to make a test appear clean.

Reset only when intentionally starting a new private chain:

```bash
bash testnet/scripts/reset-testnet.sh --confirm-testnet-reset
```

Reset stops the processes and **archives** the previous data directory. It generates new validator/oracle/admin keys and starts a new chain; old certificates are not valid on the fresh keys. Browser HMC simulation history and encrypted wallet backup are not deleted. Reset test coins are not recoverable on the new chain. For multiple lasting networks use a distinct chain ID as well; the current initializer uses `hmc-private-1`.

## Host the same Lab against the chain

The native node and oracle must run on a persistent private server, not inside the Sites Worker. Keep CometBFT RPC and oracle bound to loopback, terminate HTTPS at a reverse proxy with private access control, and permit only the intended Lab origin. Set `HMC_ALLOWED_ORIGINS` for any direct browser-to-oracle use. Add request/connection limits at the proxy.

Two connection options are implemented:

1. Set the Sites Worker `HMC_TESTNET_URL` to the private oracle's HTTPS URL. `/api/testnet/*` forwards only the supported endpoints. No admin signing endpoint exists.
2. In Lab → HMC Testnet → Testnet connection, enter your oracle HTTPS URL (localhost HTTP is allowed only for local development).

A proxy must retain private access control; browser CORS alone is not authentication. The current default loopback service is intended for an operator-controlled machine. Public deployment is not authorized or completed by these scripts.

## Create a test wallet and mine

1. Open Wallet in the existing Lab. The old ledger appears as **HMC Simulation**.
2. In **HMC-Test On-Chain Wallet**, create an encrypted wallet with a passphrase of at least 12 characters.
3. Export the encrypted backup and retain the passphrase separately. Neither secret is automatically displayed or sent to the oracle. Unlocking keeps a nonextractable signing key in this tab's memory; Lock removes that handle.
4. Open Mine, select **HMC Private Testnet**, and unlock the same wallet.
5. Choose 10 / 20 / 30 / 60 minutes (20 default) and Start Mining. Stay on the page through the session. The same challenge renderer and generation/scoring functions are reused.
6. The server generates/signs the certificate automatically on completion, within its freshness window. Click **Submit to HMC Testnet**.
7. Await a real `broadcast_tx_commit` result. Inspect the transaction/block in HMC Testnet or use View Transaction.
8. Click **Test replay protection** to submit again; the chain should reject with `Mining proof already claimed`.

The browser retains its session authorization in sessionStorage and attempts to resume in the same tab after navigation/reload. Time without live focused pulses is not credited. Closing the tab loses that authorization; background challenge misses still count. The oracle refuses to resume unfinished sessions after restart. Completed certificates and chain history remain on disk. Old simulation history remains unchanged.

Wallet addresses are `hmc` + the first 20 bytes of SHA-256(Ed25519 public key), hex encoded. **They are not Cosmos Bech32 addresses and are not compatible with Keplr.** Test wallet encryption uses PBKDF2-SHA256 (310,000 iterations), AES-256-GCM, a random 16-byte salt and 12-byte IV. This browser wallet is not a production wallet, does not defend against XSS, and has no recovery service. Never use its keys with real funds.

## Proof, signing and deterministic encoding

A transaction is a canonical JSON object whose field order matches the exported Go structs. Unknown fields and non-canonical serializations are rejected. UTF-8 JSON is signed directly with Ed25519.

`Certificate = {work, finalProofHash, nonce, issuedAt, expiresAt}`.
`finalProofHash = SHA256(JSON(work))`.

Work binds protocol version, chain ID, session ID, miner address/ID, completed-time epoch, start/end/duration, VHT, HU, challenge totals, attention/reliability/efficiency, on-chain difficulty and final challenge chain root. Time fields are Unix seconds, except session duration/VHT in milliseconds. HU is milli-HU. Scores are basis points (0–10000). Difficulty is millionths (1.0 = 1000000). No floating point is used in chain reward accounting.

The server signs with `HMC_ORACLE_SEED` or the generated local `oracle.seed`. The chain genesis contains only the public key. Seed files and runtime ledgers are excluded from Git and Site archives. Oracle rotation changes the on-chain public key effective next epoch; the operator must rotate the backend signer at that boundary too.

## Chain validation and replay protection

`MsgSubmitHumanMiningProof` verifies:

- HMP/0.1, chain ID, address and miner binding, bounded identity fields;
- deterministic work hash and 64-hex challenge commitment;
- unique session ID, final proof hash and certificate nonce;
- completed-time epoch, current or previous epoch only;
- issue/expiry window and authorized epoch oracle signature;
- 10–60 minute duration, bounded VHT and scores, bounded HU, 10–240 challenges, at least one success;
- HU equals `floor(VHT_milliseconds × efficiency_basis_points / 10000)`;
- certificate difficulty equals the epoch snapshot;
- no paused submissions; proof, epoch, UTC day and supply caps.

All successful replay identifiers are recorded in consensus state. A relayer may submit a certificate, but cannot redirect its minted balance. Signed native transfers use sender public-key/address binding and a strictly sequential account nonce. Transfers do not mint or burn.

## Rewards, epochs, difficulty and supply

Defaults: 600-second epochs; difficulty 1.0; reward pool 10 HMC-Test; reference work 1000 HU; maximum 10 HMC-Test per proof, 100 per epoch, 1000 per UTC day; experimental max supply 1,000,000,000 HMC-Test; minimum 1 HU and maximum 3600 HU/session; expiry 180 seconds.

Integer reward:

```
reward_uhmc = floor(hu_milli × epoch_pool_uhmc × 1,000,000
                   / (reference_hu_milli × difficulty_millionths))
```

HU already incorporates measured efficiency; it is not multiplied by efficiency again. The chain rejects issuance that exceeds caps instead of accepting an oracle-specified reward or silently granting an uncapped amount. Arithmetic uses big integers for the intermediate product and bounded int64 balances. Epoch HU/mint/proof/miner counts are real accepted work, not Network Simulator figures.

Parameter updates are signed by a genesis admin key, nonce-protected and effective next epoch. Prior epoch snapshots remain available for certificates at the boundary. One pending update is allowed. Current and historical difficulty are visible in Founder Console. Epoch duration is deliberately fixed at 600 seconds in v0.1 to avoid ambiguous epoch migration.

To update a parameter, create a JSON patch and run locally:

```bash
node testnet/scripts/admin.mjs parameter-patch.json
```

Example patch: `{"difficulty":1200000,"maxReward":5000000}`.
Other supported fields include `paused`, `epochCap`, `dayCap`, `maxSupply` and `oraclePublicKey`. Read the generated next-epoch values before submitting. The CLI holds admin authority; Founder Console shows state/history and prepares five principal parameter changes as a reviewable JSON patch; the private operator command signs and submits it. It does not load admin secrets into the browser. Pausing is effective next epoch, not immediate. Emergency immediate pause is not implemented.

## Explorer and persistence

The same Lab has HMC Testnet views for Blocks, Transactions, Miners, Mining Proofs, Epochs, Supply and Network. Block/transaction records come from CometBFT RPC, including transaction inclusion data. The app's committed ledger is persisted atomically via write/fsync/rename; CometBFT persists its own blocks and consensus state. App hashes are SHA-256 of canonical whole-state JSON, not a Cosmos IAVL tree. The explorer trusts its configured RPC; it is not a verifying light client.

Rejected `CheckTx` transactions never enter a block and therefore do not increment a consensus state counter. The displayed committed rejection counter covers only failed transactions in finalized blocks. It must not be presented as all attempted replays. Oracle-observed confirmation latency is labeled separately from committed state. Average block time is computed from up to 20 RPC block-header intervals. CheckTx replay counts and human multi-window research remain unmeasured; no simulated counts are substituted.

## Tests

```bash
(cd testnet && go test ./x/humanmining)
node tests/protocol.test.mjs
node tests/testnet-wallet.test.mjs
node tests/testnet-oracle.test.mjs
bash testnet/scripts/integration-run.sh
```

The oracle regression test uses an explicitly stubbed RPC to check that slow confirmation does not block other sessions, concurrent duplicate start authorizations are rejected, and uploaded HU cannot certify an incomplete session. It is not counted as a blockchain test. Wallet backup restoration verifies the signing key and public address before replacing saved data.

Go tests cover native mint/transfer, balances, tampering, wrong oracle/address/epoch, expiry, duplicate identifiers, proof/epoch/day/supply caps, admin epoch activation and persisted ABCI history. The integration test takes a real ten minutes and uses scripted timed interactions against actual validator processes. It is not an accelerated clock or fake blockchain, but also is not a manual human or browser E2E acceptance test.

## Limits before public testnet / mainnet

- Independently validate interaction evidence; the current quality telemetry is forgeable.
- Persistent authenticated infrastructure, multiple hosts/operators and durable backups. Three equal validators require all three online for >2/3 consensus; use at least four independent validators to tolerate one Byzantine/offline validator.
- Decide/adopt full Cosmos SDK bank/auth/module and Bech32 wallets if SDK compatibility is required.
- Audit consensus determinism, adversarial transactions, storage durability/crash recovery and upgrades. Whole-state JSON cloning and linear history are unsuitable at scale.
- Strong transaction rate limits/fees or quotas, oracle abuse controls and bounded evidence/history retention.
- Automated UI→oracle→chain tests plus real single/multi-window user trials, navigation/recovery and mobile validation.
- Complete Founder UI signing workflows, research rejection metrics and confirmation latency.
- Production wallet protection and external signer integration; dedicated key management/HSM, key rotation and threshold/multiple-verifier interface.
- Consensus upgrade/version migration and light-client verification; no assumption of interoperability.
- Independent security and economic review, decentralized human verification and a defensible issuance model before any Mainnet consideration.

The oracle signing boundary is separate from the issuance module. Future verifier registries, multiple attestations or threshold signatures can replace the certificate verification layer through a versioned protocol upgrade. ZK, proof-of-personhood and Human Mining consensus are future research, not implemented capabilities.

## Pre-hosting hardening checkpoint

Read `PRE-HOSTING-REPORT.ar.md` for the current acceptance decision and outstanding blockers. No permanent hosting was performed.

For a local browser with WebCrypto, configure ignored `.env.local` with `HMC_LOCAL_TESTNET=1` and, optionally, an absolute `HMC_DATA_DIR`. Then run the existing frontend development command on localhost, port 4173. The development-only Vite plugin starts the local testnet and proxies `/api/testnet`; it is excluded from production behavior. Open the application on **localhost**, or through properly configured private HTTPS. Arbitrary HTTP hostnames do not expose WebCrypto, and the wallet fails closed with a clear explanation. No insecure cryptographic fallback or browser-security override is used.

```bash
node testnet/oracle/compile.mjs
node --test tests/protocol.test.mjs tests/raw-evidence.test.mjs tests/testnet-oracle.test.mjs tests/testnet-wallet.test.mjs
(cd testnet && go test ./...)
node testnet/scripts/hardening-network.mjs
```

The network hardening script creates its own disposable ledger, runs three real validator processes, tests mint/transfer/replay/restarts and a validator outage, stops only its child processes, and retains the ledger. Its signed mining work is explicitly synthetic; it must never be reported as a browser session. Run without another testnet occupying the default ports. The 600-second API integration harness now sends raw events instead of trusted client quality, and is also not a human usability test.


Local one-command launcher: `node testnet/scripts/start-local-lab.mjs` (or `--check` for prerequisites only). It binds the frontend to loopback, selects the existing data directory and enables the development testnet bridge without editing `.env.local`. The actual local browser acceptance remains outstanding. Oracle restart regression: `node --test tests/oracle-restart.test.mjs`.
