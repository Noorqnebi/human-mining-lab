import Lab from '@/components/lab/app';
export default function Home(){return <Lab/>;}
