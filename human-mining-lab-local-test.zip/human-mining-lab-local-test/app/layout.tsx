import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Human Mining Lab | Research Workspace",
  description: "A working research lab for verified human effort, sequential proofs and simulated HMC mining.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
