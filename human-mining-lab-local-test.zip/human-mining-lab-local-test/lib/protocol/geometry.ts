export type Point={x:number;y:number};
export const distance=(a:Point,b:Point)=>Math.hypot(a.x-b.x,a.y-b.y);
export const angleGap=(a:number,b:number)=>Math.abs(((a-b+540)%360)-180);
export const pathPoints=(direction:number):Point[]=>{const ys=direction%2?[70,30,65,35]:[35,65,30,70];return ys.map((y,i)=>({x:15+i*23,y}));};
export const segmentDistance=(p:Point,a:Point,b:Point)=>{const dx=b.x-a.x,dy=b.y-a.y,t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1)));return distance(p,{x:a.x+t*dx,y:a.y+t*dy});};
export function brushCells(p:Point,seen:Set<number>){const next=new Set(seen);for(let i=0;i<20;i++){const center={x:10+(i%5)*20,y:12.5+Math.floor(i/5)*25};if(distance(p,center)<23)next.add(i)}return next;}
