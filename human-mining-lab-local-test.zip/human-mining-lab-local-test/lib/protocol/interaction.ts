import {Challenge,InteractionEvent} from './model';
export function interactionScore(c:Challenge,trace:InteractionEvent[]){
 if(!c.startedAt||!c.durationMs)return {success:false,quality:0};
 if(c.mode==='tracking'||c.mode==='adjust'){
  let coverage=0,last=c.startedAt;for(const e of trace){if(e.kind!=='track'||e.at<c.startedAt||e.at>c.startedAt+c.durationMs)continue;coverage+=Math.min(250,Math.max(0,e.at-last))*Math.min(1,Math.max(0,e.quality||0));last=e.at;}
  const quality=Math.min(1,coverage/c.durationMs);return {success:quality>=.72,quality};
 }
 const frames=c.payload.frames||[];let passed=0;
 frames.forEach((f,i)=>{const e=trace.find(e=>e.kind==='frame'&&Number(e.value)===i&&e.at>=c.startedAt!+f.at&&e.at<c.startedAt!+f.at+f.duration);if(e&&e.quality===1)passed++;});
 const quality=frames.length?passed/frames.length:0;return {success:quality>=.75,quality};
}
export function targetPosition(c:Challenge,elapsed:number){const frames=c.payload.frames||[],index=Math.max(0,frames.findLastIndex(f=>elapsed>=f.at)),current=frames[index],previous=frames[Math.max(0,index-1)];if(!current)return {x:50,y:50};const t=Math.min(1,Math.max(0,(elapsed-current.at)/Math.max(1,current.duration))),ease=t*t*(3-2*t);return {x:previous.x+(current.x-previous.x)*ease,y:c.mode==='adjust'?50:previous.y+(current.y-previous.y)*ease};}
