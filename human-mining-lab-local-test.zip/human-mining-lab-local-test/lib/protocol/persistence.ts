import {State,Session,Tx,Settings,initial,defaults} from './model';
import {metrics,reward} from './economics';
export const KEY='human-mining-lab-v1';
const DB_NAME='human-mining-lab-attention-v2';let opening:Promise<IDBDatabase>|undefined;
const request=<T,>(r:IDBRequest<T>)=>new Promise<T>((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
const complete=(t:IDBTransaction)=>new Promise<void>((resolve,reject)=>{t.oncomplete=()=>resolve();t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error||Error('Database transaction aborted.'));});
export function upgradeAttentionSettings(s:Settings):Settings {
 if(s.attentionProfile===3)return s;
 const standardFrequency=(s.frequencyMin??25)===25&&(s.frequencyMax??35)===35;
 return {...s,attentionProfile:3,frequencyMin:standardFrequency?20:s.frequencyMin,frequencyMax:standardFrequency?28:s.frequencyMax,frequency:standardFrequency?24:s.frequency,continuousPercent:(s.continuousPercent??25)===25?40:s.continuousPercent,maxChallenges:s.maxChallenges===150?240:s.maxChallenges};
}
export function migrateSettings(st:State):State {
 if(st.settings.attentionVersion===2)return {...st,settings:upgradeAttentionSettings(st.settings)};
 const settings={...st.settings,attentionVersion:2 as const,frequency:30,frequencyMin:25,frequencyMax:35,responseWindow:4,continuousPercent:25,missPenaltyStrength:'Medium' as const,attentionWeight:50,minSession:10,maxSession:60,challenges:st.settings.challenges.map(c=>({...c,weight:c.id?c.weight:defaults.challenges.find(x=>x.type===c.type)!.weight}))};
 return {...st,settings:upgradeAttentionSettings(settings)};
}
export function database():Promise<IDBDatabase>{
 if(!opening)opening=new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{for(const name of ['kv','sessions','transactions','active','attacks'])r.result.createObjectStore(name)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});return opening;
}
export async function initialize(){
 const db=await database();const existing=await request(db.transaction('kv').objectStore('kv').get('meta'));if(existing){const settings=upgradeAttentionSettings(existing.settings);if(settings!==existing.settings){const t=db.transaction('kv','readwrite'),done=complete(t);t.objectStore('kv').put({...existing,settings},'meta');await done;}return;}
 let st=initial();const raw=localStorage.getItem(KEY);
 if(raw){const parsed=JSON.parse(raw);if(parsed.version!==1||!Array.isArray(parsed.sessions)||!Array.isArray(parsed.transactions)||!parsed.settings)throw Error('Existing data is not readable. It has not been overwritten.');st=migrateSettings(parsed);try{if(!localStorage.getItem(KEY+'-before-attention'))localStorage.setItem(KEY+'-before-attention',raw)}catch{/* Original legacy key is also retained unchanged. */}}
 const t=db.transaction(['kv','sessions','transactions','attacks'],'readwrite'),done=complete(t);const kv=t.objectStore('kv');
 const gate=kv.get('meta');gate.onsuccess=()=>{if(gate.result)return;const {sessions,transactions,active,attacks,...meta}=st;kv.put(meta,'meta');for(const a of sessions)t.objectStore('sessions').put(a,a.id);for(const tx of transactions)t.objectStore('transactions').put(tx,tx.id);for(const [i,x] of attacks.entries())t.objectStore('attacks').put(x,'legacy-'+i);
 if(active&&!sessions.some(s=>s.id===active.id)){const a={...active,status:'interrupted',end:active.start+active.elapsed*1000,reward:0,bonus:0,accepted:false,reason:'Legacy session preserved during attention upgrade. No new reward credited.'};t.objectStore('sessions').put(a,a.id);}};await done;
}
export async function loadState():Promise<State>{
 const db=await database(),t=db.transaction(['kv','sessions','transactions','attacks']);const [meta,sessions,transactions,attacks]=await Promise.all([request(t.objectStore('kv').get('meta')),request(t.objectStore('sessions').getAll()),request(t.objectStore('transactions').getAll()),request(t.objectStore('attacks').getAll())]);
 return {...meta,sessions:sessions.sort((a,b)=>b.start-a.start),transactions:transactions.sort((a,b)=>b.date-a.date),attacks:attacks.sort((a,b)=>b.date-a.date),active:null};
}
export async function savePreferences(next:State,previous:State){
 const db=await database(),t=db.transaction(['kv','transactions','attacks'],'readwrite'),done=complete(t),{sessions,transactions,active,attacks,...meta}=next;t.objectStore('kv').put(meta,'meta');
 for(const tx of transactions)if(!previous.transactions.some(x=>x.id===tx.id))t.objectStore('transactions').put(tx,tx.id);
 for(const x of attacks)if(!previous.attacks.some(a=>a.date===x.date&&a.name===x.name))t.objectStore('attacks').put(x,x.date+':'+x.name);await done;
}
export async function writeActive(a:Session){const db=await database(),t=db.transaction('active','readwrite'),done=complete(t);t.objectStore('active').put(a,a.id);await done;}
export async function getActive(id:string):Promise<Session|undefined>{const db=await database();return request(db.transaction('active').objectStore('active').get(id));}
export async function listActive():Promise<Session[]>{const db=await database();return request(db.transaction('active').objectStore('active').getAll());}
// Only the short ledger commit is serialized by IndexedDB. Mining windows never acquire a lock.
export async function settleSession(session:Session):Promise<Session>{
 const db=await database(),t=db.transaction(['sessions','transactions','active'],'readwrite'),done=complete(t);let finalized=session;const store=t.objectStore('sessions');const r=store.getAll();
 r.onsuccess=()=>{const prior=r.result as Session[],duplicate=prior.find(a=>a.id===session.id);if(duplicate){finalized=duplicate;return;}const calculation=reward(session,prior),earned=session.accepted?calculation.amount:0,bonus=session.accepted?calculation.bonus:0;
 finalized={...session,reward:earned,bonus,networkHU:calculation.epochHU,pool:calculation.epochPool,allocations:calculation.allocations.map(x=>({...x,reward:session.accepted?x.reward:0}))};
 store.put(finalized,session.id);t.objectStore('active').delete(session.id);
 const txs:Tx[]=earned?[{id:session.id+':mining',date:session.end||Date.now(),type:'Mining Reward',amount:earned-bonus,session:session.id},...(bonus?[{id:session.id+':bonus',date:session.end||Date.now(),type:'Club Bonus',amount:bonus,session:session.id}]:[])]:[];
 for(const tx of txs)t.objectStore('transactions').put(tx,tx.id);};await done;return finalized;
}
export async function resetData(){const db=await database(),t=db.transaction(['kv','sessions','transactions','active','attacks'],'readwrite'),done=complete(t);for(const name of ['kv','sessions','transactions','active','attacks'])t.objectStore(name).clear();const {sessions,transactions,active,attacks,...meta}=initial();t.objectStore('kv').put(meta,'meta');await done;}
