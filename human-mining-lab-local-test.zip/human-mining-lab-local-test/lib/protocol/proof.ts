import {attentionCatalog} from './catalog';
import {interactionScore} from './interaction';
import {sha256,uuid} from './sha256';
import {Challenge,ChallengeConfig,Session,Settings,AttentionFrame,InteractionEvent} from './model';
import {attentionSettings} from './attention';
export async function hash(value:unknown){const input=new TextEncoder().encode(JSON.stringify(value));if(!crypto.subtle)return sha256(input);const bytes=await crypto.subtle.digest('SHA-256',input);return Array.from(new Uint8Array(bytes),x=>x.toString(16).padStart(2,'0')).join('');}
export const random=(n:number)=>{const max=4294967296-(4294967296%n);let x;do{x=crypto.getRandomValues(new Uint32Array(1))[0]}while(x>=max);return x%n;};
const shuffle=<T,>(xs:T[])=>{for(let i=xs.length-1;i>0;i--){const j=random(i+1);[xs[i],xs[j]]=[xs[j],xs[i]];}return xs;};
function choose(settings:Settings,previous?:Challenge){const all=settings.challenges.filter(c=>c.enabled&&c.weight>0),long=all.filter(c=>c.type==='multi'),short=all.filter(c=>c.type!=='multi');const pool=long.length&&(!short.length||random(10000)/100<attentionSettings(settings).continuous)?long:short;let r=random(100000)/100000*pool.reduce((n,c)=>n+c.weight*(c.type===previous?.type? .35:1),0);return pool.find(c=>(r-=c.weight*(c.type===previous?.type? .35:1))<0)||pool[0];}
export async function generate(a:Pick<Session,'id'|'seed'|'challenges'|'settings'>,config?:ChallengeConfig,at=Date.now(),modeOverride?:Challenge['mode']):Promise<Challenge>{
 const c=config||choose(a.settings,a.challenges.at(-1));if(!c)throw Error('Enable at least one challenge.');
 const continuous=c.type==='multi';let durationMs=(continuous?12000+random(8001):c.type==='memory'?8000+random(4001):5000+random(7001));
 const recent=a.challenges.slice(-3).map(c=>c.mode);const modes=attentionCatalog.map(c=>c.mode);const modePool=modes.flatMap(m=>Array.from({length:recent.includes(m)?1:4},()=>m));const mode=continuous?(modeOverride||modePool[random(modePool.length)]):undefined;
 const shapeModes=['wipe','path','dial','resize','balance','connect'];const shapeMode=!!mode&&shapeModes.includes(mode);if(shapeMode)durationMs=15000+random(5001);
 const actions=shuffle<AttentionFrame['action']>(['tap','swipe','hold','select','pattern','color','drag','slider','rhythm','spotlight']);
 const count=shapeMode?3:continuous?3+random(Math.min(5,Math.floor(durationMs/3000))-2):2,bounds=[0,...Array.from({length:count-1},(_,i)=>Math.round(durationMs*(i+1)/count+(random(501)-250))),durationMs];
 const frames:AttentionFrame[]=Array.from({length:count},(_,i)=>{const options=shuffle([28,40,54,70]),action=c.type==='multi'?(shapeMode?mode as AttentionFrame['action']:mode==='pattern'?'pattern':mode==='color'?'color':mode==='alternating'?'tap':mode==='drag'?'drag':mode==='slider'?'slider':mode==='rhythm'?'rhythm':mode==='spotlight'?'spotlight':actions[i]):(c.type==='selection'&&random(2)?'color':({target:'tap',direction:'swipe',memory:'memory',selection:'select',hold:'hold'} as const)[c.type]);return {cueStart:.20+random(2501)/10000,cueEnd:.80+random(1001)/10000,at:bounds[i],duration:bounds[i+1]-bounds[i],action,color:random(3),direction:random(4),options,answer:action==='spotlight'?random(6):options.indexOf(70),pattern:Array.from({length:4},()=>random(3)),x:25+random(51),y:30+random(41)};});
 const options=frames[0].options,payload={answer:options.indexOf(70),options,pattern:frames[0].pattern,direction:frames[0].direction,holdMs:1500,color:frames[0].color,frames};
 const previousChallengeHash=a.challenges.at(-1)?.chainHash||a.seed;
 const data={id:uuid(),sessionId:a.id,type:c.type,configKey:c.id||c.type,generatedAt:at,displayedAt:at,expiresAt:at+attentionSettings(a.settings).response*1000,difficulty:c.difficulty,previousChallengeHash,payload,protocolVersion:2 as const,durationMs,continuous,mode,startDeadlineAt:at+attentionSettings(a.settings).response*1000};
 return {...data,challengeHash:await hash(data),status:'waiting'};
}
export function beginChallenge(c:Challenge,at=Date.now()):Challenge|null {
 if(c.startedAt||c.completedAt||at>=(c.startDeadlineAt??c.expiresAt))return null;
 return {...c,startedAt:at,status:'running'};
}
export const completionDeadline=(c:Challenge)=>c.startedAt?c.startedAt+(c.durationMs||0)+2000:(c.startDeadlineAt||c.expiresAt);
function responseData(c:Challenge){
 const base={completedAt:c.completedAt,responseTime:c.responseTime,success:c.success,accuracy:c.accuracy,qualityScore:c.qualityScore,response:c.response};
 return c.protocolVersion===2?{...base,startedAt:c.startedAt,status:c.status,interactionTrace:c.interactionTrace,focusAtCompletion:c.focusAtCompletion,verifiedInterval:c.verifiedInterval}:base;
}
function challengeData(c:Challenge){
 const {id,sessionId,type,configKey,generatedAt,displayedAt,expiresAt,difficulty,previousChallengeHash,payload}=c;
 const base={id,sessionId,type,configKey,generatedAt,displayedAt,expiresAt,difficulty,previousChallengeHash,payload};
 return c.protocolVersion===2?{...base,protocolVersion:c.protocolVersion,durationMs:c.durationMs,continuous:c.continuous,mode:c.mode,startDeadlineAt:c.startDeadlineAt}:base;
}
export async function resolveChallenge(c:Challenge,success:boolean,accuracy:number,response:unknown,s:Settings,at=Date.now(),context?:{focusedSeconds:number;previousFocus:number;trace:InteractionEvent[]}):Promise<Challenge>{
 const cfg=s.challenges.find(x=>(x.id||x.type)===(c.configKey||c.type));
 const timed=c.protocolVersion===2,attestation=timed?interactionScore(c,context?.trace||[]):{success:true,quality:accuracy};
 const ok=timed?success&&attestation.success&&!!c.startedAt&&c.startedAt<(c.startDeadlineAt||0)&&at>=c.startedAt+(c.durationMs||0)&&at<=completionDeadline(c):success&&at<=c.expiresAt&&at-c.displayedAt>=Math.max(s.fraudFast,cfg?.minMs||0);
 const q=ok?Math.min(1,Math.max(0,accuracy),attestation.quality)**(cfg?.qualityWeight||1):0;
 let result:Challenge={...c,completedAt:at,responseTime:timed?(c.startedAt?c.startedAt-c.displayedAt:at-c.displayedAt):at-c.displayedAt,success:ok,accuracy,qualityScore:q,response};
 if(timed)result={...result,status:!c.startedAt?'missed':ok?'passed':'failed',interactionTrace:context?.trace||[],focusAtCompletion:context?.focusedSeconds||0,verifiedInterval:ok?Math.max(0,(context?.focusedSeconds||0)-(context?.previousFocus||0)):0};
 const responseHash=await hash(responseData(result)),chainHash=await hash([c.previousChallengeHash,c.challengeHash,responseHash]);
 return {...result,responseHash,chainHash};
}
export async function verify(a:Session){let prev=a.seed;for(const c of a.challenges){const expected=await hash(challengeData(c)),responseHash=await hash(responseData(c));if(c.sessionId!==a.id||c.previousChallengeHash!==prev||c.challengeHash!==expected||c.responseHash!==responseHash||c.chainHash!==await hash([prev,expected,responseHash]))return false;prev=c.chainHash!;}return prev===a.proof;}
export function fraud(name:string,s:Settings){const map:Record<string,[number,string]>={'Tab left open':[100,'No completed verification: zero HU.'],'Failed challenges':[95,'Failed responses do not contribute verified intervals.'],'Impossibly fast':[99,'A response cannot finish before the challenge’s required duration.'],'Identical timing':[80,'Timing variance is an observation, not a forced rejection in attention trials.'],'Replay old challenge':[100,'Challenge ID and prior chain hash do not match the active proof.'],'Concurrent sessions':[0,'Concurrent windows are permitted. Compare their observed attention, misses, HU and efficiency in Parallel resistance.'],'Bot-like responses':[85,'Synthetic heuristic only; no production bot-resistance claim.'],'Low attention':[70,'Unfocused time is excluded and missed starts reduce measured efficiency.']};const [score,reason]=map[name]||[0,'Unknown scenario'];return {date:Date.now(),name,fraud:score,reason};}
