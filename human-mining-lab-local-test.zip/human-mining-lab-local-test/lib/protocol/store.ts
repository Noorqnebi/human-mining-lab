'use client';
import {uuid} from './sha256';
import {useEffect,useRef,useState} from 'react';
import {initial,State,Session,Challenge,InteractionEvent} from './model';
import {generate,hash,random,resolveChallenge,verify,beginChallenge,completionDeadline} from './proof';
import {metrics,network} from './economics';
import {attentionMetrics,advanceAttention,changeAttention,nextChallengeSchedule} from './attention';
import * as persistence from './persistence';
export {KEY} from './persistence';
export function useLab(){
 const [state,setState]=useState<State>(initial),[ready,setReady]=useState(false),[error,setError]=useState(''),[liveSessions,setLive]=useState<Session[]>([]);
 const ref=useRef(state),busy=useRef(false),finishing=useRef(false),running=useRef(false),lastWrite=useRef(0),channel=useRef<BroadcastChannel|null>(null);
 const display=(next:State)=>{ref.current=next;setState(next)};
 const fail=(e:unknown)=>setError('Could not save lab data: '+(e instanceof Error?e.message:String(e))+'. Existing records are retained.');
 const refresh=async()=>{const st=await persistence.loadState();display({...st,active:ref.current.active});};
 const persistActive=(a:Session)=>{const old=ref.current.active;if(old?.id===a.id&&(old.lastTick||0)>(a.lastTick||0))a={...a,lastTick:old.lastTick,elapsed:old.elapsed,visible:old.visible,backgroundTime:old.backgroundTime,focused:old.focused,hidden:old.hidden,focusLossEvents:old.focusLossEvents,backgroundEvents:old.backgroundEvents,attentionEvents:old.attentionEvents};const force=old?.pending?.id!==a.pending?.id||old?.pending?.startedAt!==a.pending?.startedAt||old?.challenges.length!==a.challenges.length||old?.focused!==a.focused;display({...ref.current,active:a});if(force||Date.now()-lastWrite.current>1000){lastWrite.current=Date.now();void persistence.writeActive(a).catch(fail);}};
 useEffect(()=>{let disposed=false;void (async()=>{try{await persistence.initialize();const st=await persistence.loadState();const navigation=performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming|undefined;
 const previousId=sessionStorage.getItem('hml-current-window-session');if(previousId&&navigation?.type==='reload')st.active=await persistence.getActive(previousId)||null;
 if(!disposed){display(st);setReady(true);}
 }catch(e){fail(e);}})();
 if(typeof BroadcastChannel!=='undefined'){channel.current=new BroadcastChannel('hml-attention-updates');channel.current.onmessage=()=>{void refresh().catch(fail);};}
 const poll=setInterval(()=>{void persistence.listActive().then(xs=>{if(!disposed)setLive(xs.filter(a=>a.start+a.planned*1000>Date.now()))}).catch(()=>{});},2000);
 return()=>{disposed=true;clearInterval(poll);channel.current?.close();};},[]);
 const update=(fn:(s:State)=>State)=>{const previous=ref.current,next=fn(previous);display(next);void persistence.savePreferences(next,previous).then(()=>channel.current?.postMessage('settings')).catch(fail);};
 const endPending=async(a:Session,ok:boolean,quality:number,response:unknown,trace:InteractionEvent[]=[],at=Date.now())=>{
 if(!a.pending)return a;const c=a.pending,previousFocus=a.challenges.at(-1)?.focusAtCompletion||0;
 const resolved=await resolveChallenge(c,ok,quality,response,a.settings,at,{focusedSeconds:a.visible,previousFocus,trace});
 const schedule=nextChallengeSchedule(a.settings,c.displayedAt,at,!!a.afterBurst);
 return {...a,confirmedVht:(a.confirmedVht||0)+(resolved.verifiedInterval||0),challenges:[...a.challenges,resolved],pending:undefined,nextAt:schedule.nextAt,nextIsBurst:schedule.burst,afterBurst:false};
 };
 const finish=async(status:Session['status']='completed')=>{
  if(finishing.current||!ref.current.active)return;finishing.current=true;running.current=false;
  try{let a=advanceAttention(ref.current.active,Date.now());if(a.pending)a=await endPending(a,false,0,{reason:'session-ended'},[],Date.now());
   const m=attentionMetrics(a);a.proof=a.challenges.at(-1)?.chainHash||a.seed;const integrity=await verify(a);
   const accepted=integrity&&status!=='interrupted'&&a.elapsed>=a.settings.minSession*60&&a.challenges.length>=a.settings.minChallenges&&a.challenges.some(c=>c.success)&&m.hu>0;
   const candidate:Session={...a,end:Date.now(),status,accepted,hu:accepted?m.hu:0,vht:m.vht,quality:m.q,reliability:m.reliability,efficiency:m.efficiency,attentionScore:m.attentionScore,missPenalty:m.penalty,timeContribution:m.timeContribution,challengeContribution:m.challengeContribution,qualityContribution:m.qualityContribution,reason:accepted?'Chain integrity and minimum work passed. Reward reflects measured attention and progressive missed-start penalties.':status==='interrupted'?'Interrupted session preserved without a new reward.':'Insufficient verified work, minimum duration/count not reached, or proof integrity failed.'};
   const saved=await persistence.settleSession(candidate);sessionStorage.removeItem('hml-current-window-session');display({...ref.current,active:null});await refresh();channel.current?.postMessage('settled');return saved;
  }catch(e){fail(e);throw e}finally{finishing.current=false;}
 };
 useEffect(()=>{if(!ready)return;const tick=async()=>{if(!running.current||busy.current||finishing.current||!ref.current.active)return;busy.current=true;
  try{const now=Date.now();let a=advanceAttention(ref.current.active,now);const until=Math.min(now,a.start+a.planned*1000);
   for(let caught=0;caught<200;caught++){
    if(a.pending&&until>=completionDeadline(a.pending)){const deadline=completionDeadline(a.pending);a=await endPending(a,false,0,{reason:a.pending.startedAt?'completion-timeout':'start-window-missed'},[],deadline);continue;}
    if(!a.pending&&a.nextAt<=until&&a.nextAt<a.start+a.planned*1000&&a.challenges.length<a.settings.maxChallenges){const c=await generate(a,undefined,a.nextAt);a={...a,pending:c,bursts:(a.bursts||0)+(a.nextIsBurst?1:0),afterBurst:a.nextIsBurst,nextIsBurst:false};if(until<(c.startDeadlineAt||0)&&ref.current.vibration)navigator.vibrate?.([80,50,80]);continue;}
    break;
   }
   if(a.elapsed>=a.planned){display({...ref.current,active:a});await finish();}
   else {
    // Events may have changed focus while hashing. Never restore an outdated focused state.
    const latest=ref.current.active;if(latest){a={...a,focused:latest.focused,hidden:latest.hidden,focusLossEvents:Math.max(a.focusLossEvents||0,latest.focusLossEvents||0),backgroundEvents:Math.max(a.backgroundEvents||0,latest.backgroundEvents||0),attentionEvents:latest.attentionEvents};}persistActive(a);}
  }catch(e){fail(e)}finally{busy.current=false;}};
 const onAttention=()=>{if(!running.current||!ref.current.active)return;const hidden=document.visibilityState!=='visible',focused=!hidden&&document.hasFocus();const a=ref.current.active;if(focused===a.focused&&hidden===a.hidden)return;persistActive(changeAttention(a,Date.now(),focused,hidden));};
 const timer=setInterval(()=>void tick(),250);document.addEventListener('visibilitychange',onAttention);window.addEventListener('focus',onAttention);window.addEventListener('blur',onAttention);
 const unload=(e:BeforeUnloadEvent)=>{if(running.current&&ref.current.active){e.preventDefault();e.returnValue='A mining session is active.';}};window.addEventListener('beforeunload',unload);
 return()=>{clearInterval(timer);document.removeEventListener('visibilitychange',onAttention);window.removeEventListener('focus',onAttention);window.removeEventListener('blur',onAttention);window.removeEventListener('beforeunload',unload)};
 },[ready]);
 const start=async(minutes:number)=>{
  if(ref.current.active)throw Error('This window already has a session. Open another window for a parallel trial.');
  const s=ref.current.settings;if(![10,20,30,60].includes(minutes)||minutes<s.minSession||minutes>s.maxSession)throw Error('Choose a supported duration within Founder limits.');
  if(!s.challenges.some(c=>c.enabled&&c.weight>0))throw Error('Enable at least one challenge.');
  const now=Date.now(),id=uuid(),seed=await hash([id,now,crypto.getRandomValues(new Uint32Array(8))]);
  const hidden=document.visibilityState!=='visible',focused=!hidden&&document.hasFocus();
  const a:Session={protocolVersion:2,id,seed,start:now,planned:minutes*60,elapsed:0,visible:0,confirmedVht:0,backgroundTime:0,backgroundEvents:0,focusLossEvents:0,attentionEvents:[{at:now,focused,hidden}],focused,hidden,lastTick:now,bursts:0,club:ref.current.club,settings:structuredClone(s),challenges:[],nextAt:now+(s.frequencyMin!+random(100000)/100000*(s.frequencyMax!-s.frequencyMin!))*1000,status:'active',hu:0,vht:0,quality:0,reliability:1,reward:0,bonus:0,difficulty:network(s).difficulty,proof:seed,accepted:false,reason:'',epoch:Math.floor(now/(s.epochMinutes*60000)),networkHU:0,pool:0,price:s.price};
  await persistence.writeActive(a);sessionStorage.setItem('hml-current-window-session',id);running.current=true;display({...ref.current,active:a});
 };
 const begin=async(id:string)=>{const a=ref.current.active;if(!a?.pending||a.pending.id!==id||!a.focused||document.visibilityState!=='visible'||!document.hasFocus())return false;
  const started=beginChallenge(a.pending,Date.now());if(!started)return false;persistActive({...advanceAttention(a,Date.now()),pending:started});return true;
 };
 const respond=async(c:Challenge,ok:boolean,quality:number,response:unknown,trace:InteractionEvent[]=[])=>{
  if(finishing.current||ref.current.active?.pending?.id!==c.id)return false;
  // Async finalization is queued behind the brief engine tick; do not drop a valid click.
  while(busy.current)await new Promise(r=>setTimeout(r,5));if(ref.current.active?.pending?.id!==c.id)return false;busy.current=true;
  try{const a=advanceAttention(ref.current.active,Date.now()),n=await endPending(a,ok&&!!a.focused,quality,response,trace);persistActive(n);return !!n.challenges.at(-1)?.success;}finally{busy.current=false;}
 };
 const reset=async()=>{if(ref.current.active)throw Error('End this window’s session before reset.');await persistence.resetData();await refresh();channel.current?.postMessage('reset');};
 return {state,ready,error,update,start,begin,respond,finish,reset,liveSessions,recover:()=>finish('interrupted'),isRecovered:!!state.active&&!running.current};
}
