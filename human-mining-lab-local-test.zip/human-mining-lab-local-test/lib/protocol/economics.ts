import {attentionMetrics} from './attention';
import {Settings,Session,clamp} from './model';
export function network(s:Settings){
 const shares=s.clubs.reduce((a,c)=>a+c.share,0)||1;
 const clubs=s.clubs.map(c=>{const members=s.miners*c.share/shares;const time=Math.min(s.minutes,c.minutes)*c.usage/100;const hu=time*60*(s.success/100)*Math.pow(s.quality/100,s.qualityWeight)*s.huPerSecond*s.difficultyWeight*s.timeWeight;return {...c,members,time,hu,weighted:hu*c.multiplier,total:members*hu*c.multiplier};});
 const hu=clubs.reduce((a,c)=>a+c.total,0);const hours=clubs.reduce((a,c)=>a+c.members*c.time/60,0);
 const difficulty=clamp(s.base*Math.pow(hu/Math.max(1,s.targetHU),s.sensitivity),s.minDifficulty,s.maxDifficulty);
 const mint=Math.min(s.emission,s.emissionCap,Math.max(0,s.maxSupply-s.supply));
 const pool=mint*Math.max(0,1-(s.treasury+s.validator)/100);
 return {clubs,hu,hours,difficulty,mint,pool,rate:hu>0?pool/hu:0,avg:pool/Math.max(1,s.miners),burn:mint*s.burn/100,marketCap:s.supply*s.price,fdv:s.maxSupply*s.price};
}
export function metrics(a:Session){
 if(a.protocolVersion===2)return attentionMetrics(a);
 const cs=a.challenges,passed=cs.filter(c=>c.success).length,success=cs.length?passed/cs.length:0;
 const q=cs.length?cs.reduce((n,c)=>n+(c.qualityScore||0),0)/cs.length:0;
 const reliability=a.elapsed>0?Math.min(1,a.visible/a.elapsed):0;
 const vht=Math.min(a.elapsed,a.visible*success*Math.pow(q,a.settings.qualityWeight)*Math.pow(reliability,a.settings.reliabilityWeight)*a.settings.timeWeight);
 const hu=vht*a.settings.huPerSecond*a.settings.difficultyWeight;
 return {success,q,reliability,vht,hu};
}
export function reward(a:Session,prior:Session[]=[]){
 const m=metrics(a),s=a.settings,n=network(s),duration=Math.max(1,a.elapsed),epochMs=s.epochMinutes*60000;
 const end=a.start+a.elapsed*1000,allocations:NonNullable<Session['allocations']>=[];
 const lifetime=prior.reduce((v,x)=>v+x.reward,0);let total=0;
 for(let cursor=a.start;cursor<end;){
  const epoch=Math.floor(cursor/epochMs),day=new Date(cursor).toISOString().slice(0,10),midnight=Date.parse(day+'T00:00:00Z')+86400000;
  const stop=Math.min(end,(epoch+1)*epochMs,midnight),fraction=(stop-cursor)/1000/duration,weighted=m.hu*s.clubs[a.club].multiplier*fraction;
  const key=s.epochMinutes+':'+epoch,epochHU=n.hu*s.epochMinutes/1440,epochPool=n.pool*s.epochMinutes/1440;
  const past=prior.flatMap(x=>x.allocations||[{key:x.settings.epochMinutes+':'+x.epoch,day:new Date(x.start).toISOString().slice(0,10),epoch:x.epoch,reward:x.reward,pool:x.pool,hu:x.hu}]);
  const usedEpoch=[...past,...allocations].filter(x=>x.key===key).reduce((v,x)=>v+x.reward,0),usedDay=[...past,...allocations].filter(x=>x.day===day).reduce((v,x)=>v+x.reward,0);
  const raw=weighted/(epochHU+weighted||1)*epochPool;
  const amount=Math.max(0,Math.min(raw,s.maxReward-total,epochPool-usedEpoch,n.pool-usedDay,s.maxSupply-s.supply-lifetime-total));
  allocations.push({key,day,epoch,reward:amount,pool:epochPool,hu:weighted});total+=amount;cursor=stop;
 }
 if(total<s.minReward){total=0;allocations.forEach(x=>x.reward=0);}
 return {amount:total,bonus:total*(1-1/s.clubs[a.club].multiplier),epochHU:n.hu*s.epochMinutes/1440,epochPool:n.pool*s.epochMinutes/1440,allocations,...m};
}
export function travel(s:Settings,days:number){
 let supply=s.supply,totalMint=0,totalBurn=0;const points=[];let nextAdjustment=0,lastDifficulty=network(s).difficulty;
 for(let day=0;day<=days;day++){
  const t=day/365,g=s.growth/100;let miners=s.miners;
  if(s.growthModel==='Linear')miners=s.miners*(1+g*t);
  else if(s.growthModel==='Exponential')miners=s.miners*Math.pow(1+g,t);
  else if(s.growthModel==='S-Curve')miners=s.growthTarget/(1+(s.growthTarget/Math.max(1,s.miners)-1)*Math.exp(-g*t));
  else miners=s.miners+(s.growthTarget-s.miners)*Math.min(1,day/1095);
  miners=clamp(miners,1,100000000);const n=network({...s,miners,supply,emission:Math.min(s.emission*Math.pow(1+s.inflation/100,t),Math.max(0,s.maxSupply-s.supply-totalMint))});
  if(day>=nextAdjustment){lastDifficulty=n.difficulty;nextAdjustment=(Math.floor(day/(s.adjustEpochs*s.epochMinutes/1440))+1)*(s.adjustEpochs*s.epochMinutes/1440);}
  const burn=Math.min(supply+n.mint,n.mint*s.burn/100+s.fees+s.clubBurn);
  const price=s.price*Math.pow(1+s.priceGrowth/100,t);
  if(day%Math.max(1,Math.floor(days/60))===0||day===days)points.push({day,label:day+'d',supply,miners,difficulty:lastDifficulty,reward:n.avg,price,marketCap:supply*price,mint:n.mint,burn,inflation:supply?(n.mint-burn)*365/supply*100:0,totalMint,totalBurn});
  if(day<days){supply=Math.min(s.maxSupply,Math.max(0,supply+n.mint-burn));totalMint+=n.mint;totalBurn+=burn;}
 }return points;
}
export const demoData=(s:Settings)=>Array.from({length:30},(_,i)=>{const n=network({...s,miners:Math.round(s.miners*(.55+.45*i/29))});return {label:new Date(Date.now()-(29-i)*86400000).toLocaleDateString('en-US',{month:'short',day:'numeric'}),difficulty:n.difficulty,miners:s.miners*(.55+.45*i/29),hu:n.hu,earnings:n.avg*(.75+Math.sin(i*1.7)*.15),emission:n.mint,supply:Math.max(0,s.supply-(29-i)*n.mint),price:s.price*(.9+.1*i/29),hours:n.hours,success:85+Math.sin(i)*5, fraud:Math.round(3+2*Math.sin(i)),marketCap:Math.max(0,s.supply-(29-i)*n.mint)*s.price};});
