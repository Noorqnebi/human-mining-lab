import {Session,Settings,clamp} from './model';
export const attentionSettings=(s:Settings)=>({min:s.frequencyMin??20,max:s.frequencyMax??28,response:s.responseWindow??4,continuous:s.continuousPercent??40,strength:s.missPenaltyStrength??'Medium',weight:(s.attentionWeight??50)/100});
export function nextChallengeSchedule(s:Settings,displayedAt:number,completedAt:number,afterBurst=false,rng:()=>number=()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296){
 const cfg=attentionSettings(s),scale=(cfg.min+cfg.max)/60,u=rng();let gap:number,burst=false;
 if(afterBurst&&u<.85)gap=(40+10*rng())*scale;
 else if(u<.15){gap=(8+7*rng())*scale;burst=true;}
 else if(u>.97)gap=(40+10*rng())*scale;
 else {const onset=(cfg.min-2)+Math.max(1,cfg.max-cfg.min-3)*rng();gap=Math.max(4*scale,onset-(completedAt-displayedAt)/1000);}
 return {nextAt:completedAt+gap*1000,burst,gap};
}
export const missPenalty=(misses:number,s:Settings)=>Math.exp(-({Light:.0015,Medium:.003,Strong:.005}[s.missPenaltyStrength??'Medium'])*Math.pow(Math.max(0,misses),2.3));
export function attentionMetrics(a:Session){
 const cs=a.challenges,passed=cs.filter(c=>c.success),count=cs.length,missed=cs.filter(c=>c.status==='missed').length;
 const success=count?passed.length/count:0,q=passed.length?passed.reduce((n,c)=>n+(c.qualityScore||0),0)/passed.length:0;
 const focused=Math.min(a.elapsed,a.visible),focusShare=a.elapsed>0?focused/a.elapsed:0;
 const reliability=clamp(focusShare*Math.exp(-.0075*(a.focusLossEvents||0)),0,1),last=cs.at(-1);
 const tail=last?.success?Math.min(Math.max(0,focused-(last.focusAtCompletion||0)),Math.max(50,(a.settings.frequencyMax??28)*2)):0;
 const vht=Math.min(focused,(a.confirmedVht||0)+tail),timeRatio=a.elapsed>0?vht/a.elapsed:0;
 const w=attentionSettings(a.settings).weight,penalty=missPenalty(missed,a.settings);
 const timeContribution=w*timeRatio,challengeContribution=(1-w)*.6*success,qualityContribution=(1-w)*.4*(q*.7+reliability*.3);
 const efficiency=count&&passed.length?clamp((timeContribution+challengeContribution+qualityContribution)*penalty,0,1):0;
 const continuous=cs.filter(c=>c.continuous),continuousQuality=continuous.length?continuous.reduce((n,c)=>n+(c.qualityScore||0),0)/continuous.length:success;
 const attentionScore=count?clamp(.6*timeRatio+.25*(1-missed/count)+.15*continuousQuality,0,1):0;
 const hu=vht*efficiency*a.settings.huPerSecond*a.settings.difficultyWeight;
 const gaps=cs.slice(1).map((c,i)=>(c.displayedAt-cs[i].displayedAt)/1000);
 return {success,q,reliability,vht,hu,efficiency,attentionScore,missed,penalty,timeContribution,challengeContribution,qualityContribution,density:a.elapsed?count/(a.elapsed/60):0,averageGap:gaps.length?gaps.reduce((n,x)=>n+x,0)/gaps.length:0,continuousCompleted:continuous.filter(c=>c.success).length,continuousCount:continuous.length,focusLossRate:a.elapsed?(a.focusLossEvents||0)/(a.elapsed/60):0,humanLoad:a.elapsed?cs.reduce((n,c)=>n+(c.startedAt?Math.max(0,(c.completedAt||c.startedAt)-c.startedAt)/1000:0),0)/a.elapsed:0};
}
// Flush elapsed time before a visibility/focus transition, then change state.
// No hidden/unfocused interval is ever added on return; suspension gaps are conservative.
export function advanceAttention(a:Session,at:number):Session {
 const end=Math.min(at,a.start+a.planned*1000),previous=a.lastTick??a.start,dt=Math.max(0,(end-previous)/1000);
 const accounted=a.focused?Math.min(dt,1.5):0;
 return {...a,lastTick:end,elapsed:Math.min(a.planned,Math.max(0,(end-a.start)/1000)),visible:a.visible+accounted,backgroundTime:(a.backgroundTime||0)+(a.focused?Math.max(0,dt-accounted):dt)};
}
export function changeAttention(a:Session,at:number,focused:boolean,hidden:boolean):Session {
 const n=advanceAttention(a,at),loss=a.focused&&!focused;
 return {...n,focused,hidden,focusLossEvents:(a.focusLossEvents||0)+(loss?1:0),backgroundEvents:(a.backgroundEvents||0)+(!a.hidden&&hidden?1:0),attentionEvents:[...(a.attentionEvents||[]),{at,focused,hidden}]};
}
export function researchMetrics(sessions:Session[]){
 const tested=sessions.filter(a=>a.protocolVersion===2&&a.elapsed>0),seconds=tested.reduce((n,a)=>n+a.elapsed,0),cs=tested.flatMap(a=>a.challenges),count=cs.length;
 const weighted=(key:'attentionScore'|'efficiency'|'humanLoad')=>seconds?tested.reduce((n,a)=>n+attentionMetrics(a)[key]*a.elapsed,0)/seconds:0;
 const miss=count?cs.filter(c=>c.status==='missed').length/count:0,focusRate=seconds?tested.reduce((n,a)=>n+(a.focusLossEvents||0),0)/(seconds/60):0;
 const focusShare=seconds?tested.reduce((n,a)=>n+a.visible,0)/seconds:0;
 const groups=[1,2,3,5].map(windows=>{const group=tested.filter(a=>{const mid=(a.start+(a.end||a.start+a.elapsed*1000))/2;const overlaps=tested.filter(b=>b.start<=mid&&(b.end||b.start+b.elapsed*1000)>=mid).length;return windows===5?overlaps>=5:overlaps===windows});const elapsed=group.reduce((n,a)=>n+a.elapsed,0);return {windows,label:windows===5?'5+':String(windows),samples:group.length,efficiency:elapsed?group.reduce((n,a)=>n+attentionMetrics(a).efficiency*a.elapsed,0)/elapsed*100:null,hu:group.reduce((n,a)=>n+a.hu,0),reward:group.reduce((n,a)=>n+a.reward,0)};});
 return {samples:tested.length,attention:weighted('attentionScore'),efficiency:weighted('efficiency'),density:seconds?count/(seconds/60):0,miss,focusRate,load:weighted('humanLoad'),risk:clamp(.45*miss+.35*(1-focusShare)+.2*Math.min(1,focusRate/4),0,1),groups};
}
