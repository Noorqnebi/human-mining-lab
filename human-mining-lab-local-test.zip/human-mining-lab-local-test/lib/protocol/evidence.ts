import {Challenge,InteractionEvent} from './model';
import {targetPosition} from './interaction';
import {angleGap,brushCells,distance,pathPoints,segmentDistance} from './geometry';
export type RawInput={challengeId:string;nonce:string;seq:number;frame:number;kind:string;x?:number;y?:number;value?:number;down?:boolean;phase?:string};
export type EvidenceState={seq:number;frames:Record<number,any>;trace:InteractionEvent[];raw:(RawInput&{receivedAt:number})[]};
export const newEvidence=():EvidenceState=>({seq:0,frames:{},trace:[],raw:[]});
// Only the oracle calls this with its own clock and issued challenge. No client
// grades, durations, timestamps, target positions or cumulative coverage accepted.
export function receiveEvidence(c:Challenge,nonce:string,state:EvidenceState,e:RawInput,now:number){
 if(!e||Object.keys(e).some(k=>!['challengeId','nonce','seq','frame','kind','x','y','value','down','phase'].includes(k)))throw Error('Unknown raw evidence field');
 if(e.challengeId!==c.id||e.nonce!==nonce||!Number.isSafeInteger(e.seq)||e.seq<=state.seq||e.seq>state.seq+100)throw Error('Raw evidence binding or sequence invalid');
 if(!c.startedAt||now<c.startedAt||now>=c.startedAt+(c.durationMs||0))throw Error('Raw evidence outside challenge window');
 if(!Number.isInteger(e.frame)||e.frame<0||!['track','choice','tap','tap-key','swipe-key','hold-down','hold-up','hold-cancel','beat','pointer','steer','sample'].includes(e.kind))throw Error('Invalid evidence type');
 for(const key of ['x','y','value'] as const)if(e[key]!==undefined&&(!Number.isFinite(e[key])||Math.abs(e[key]!)>1000))throw Error('Invalid evidence coordinate');
 if(e.down!==undefined&&typeof e.down!=='boolean')throw Error('Invalid pointer state');
 if(state.raw.length>=1000)throw Error('Evidence budget exceeded');
 const frames=c.payload.frames||[],i=frames.findLastIndex(f=>now>=c.startedAt!+f.at);if(e.frame!==i)throw Error('Evidence belongs to a different instruction');
 state.seq=e.seq;state.raw.push({...e,receivedAt:now});const f=frames[i];if(!f)return;
 if(c.mode==='tracking'||c.mode==='adjust'){if(e.kind!=='track')throw Error('Tracking requires coordinates');const target=targetPosition(c,now-c.startedAt);const hit=e.down===true&&Number.isFinite(e.x)&&Number.isFinite(e.y)&&(c.mode==='adjust'?Math.abs(e.x!-target.x)<=20:Math.hypot(e.x!-target.x,e.y!-target.y)<=25);state.trace.push({kind:'track',at:now,quality:hit?1:0});return;}
 const st=state.frames[i]||(state.frames[i]={lastAt:now,position:f.direction%2?25:75,stable:0,steer:0,steerTime:0,points:[],cells:[],links:[],rotation:0});
 if(st.done)return;const finish=(ok:boolean)=>{st.done=true;state.trace.push({kind:'frame',value:i,at:now,quality:ok?1:0})};
 const elapsed=now-c.startedAt-f.at,signal=elapsed>=f.duration*(f.cueStart??.3)&&elapsed<f.duration*(f.cueEnd??.85);
 if(f.action==='balance'){const dt=Math.max(0,Math.min(.3,(now-st.lastAt)/1000));st.position=Math.max(5,Math.min(95,st.position+((f.direction%2?12:-12)+st.steer*32)*dt));st.stable=st.position>=35&&st.position<=65?st.stable+dt:0;st.steerTime+=Math.abs(st.steer)*dt;if(e.kind==='steer'&&[-1,0,1].includes(e.value!))st.steer=e.value;if(st.stable>=1.2&&st.steerTime>=.2)finish(true);st.lastAt=now;return;}
 if(e.kind==='choice'){
  if(f.action==='select')finish(e.value===f.answer);
  else if(f.action==='memory')finish(elapsed>=f.duration*.45&&e.value===f.color);
  else if(f.action==='color')finish(e.value===f.color);
  else if(f.action==='slider')finish(Math.abs(e.value!-f.x)<=12);
  else if(f.action==='spotlight')finish(signal&&e.value===f.answer);
  return;
 }
 if(e.kind==='tap-key'&&f.action==='tap'){finish(true);return;}
 if(e.kind==='tap'){if(f.action==='tap')finish(Number.isFinite(e.x)&&Math.abs(e.x!-f.x)<=25);else if(f.action==='pattern')finish(signal);return;}
 if(e.kind==='swipe-key'&&f.action==='swipe'){finish(e.value===f.direction);return;}
 if(e.kind==='hold-cancel'){delete st.holdAt;return;}
 if(e.kind==='hold-down'&&f.action==='hold'){st.holdAt??=now;return;}
 if(e.kind==='hold-up'&&f.action==='hold'){const duration=st.holdAt===undefined?-1:now-st.holdAt,needed=Math.min(1500,f.duration*.5);finish(duration>=needed-100&&duration<=needed+1400);return;}
 if(e.kind==='beat'&&f.action==='rhythm'){if(st.beat===undefined)st.beat=now;else finish(now-st.beat>=500+(f.cueStart??.3)*1000-100&&now-st.beat<=1800+(f.cueStart??.3)*1000);return;}
 if(e.kind!=='pointer'||!Number.isFinite(e.x)||!Number.isFinite(e.y)||!['down','move','up','cancel'].includes(e.phase!))return;
 const p={x:e.x!,y:e.y!};if(e.phase==='cancel'){st.down=false;st.last=null;return;}
 if(e.phase==='down'){st.down=true;st.start=p;st.last=p;st.points=[p];if(f.action==='path')st.step=distance(p,pathPoints(f.direction)[0])<=14?1:0;if(f.action==='connect')st.from=[0,1,2].find(j=>distance(p,{x:18,y:20+j*30})<15&&!st.links.includes(j));}
 if(!st.down)return;
 if(f.action==='wipe'){st.cells=[...brushCells(p,new Set(st.cells))];if(st.cells.length>=14)finish(true)}
 if(f.action==='path'&&st.step){const path=pathPoints(f.direction);if(distance(st.last,p)>25||segmentDistance(p,path[st.step-1],path[st.step])>17){st.step=0;st.down=false}else if(distance(p,path[st.step])<12){if(st.step===3)finish(true);else st.step++}}
 if(f.action==='dial'){const a=(Math.atan2(p.y-50,p.x-50)*180/Math.PI+450)%360,prior=(Math.atan2(st.last.y-50,st.last.x-50)*180/Math.PI+450)%360;st.rotation+=angleGap(a,prior);if(e.phase==='up'&&st.rotation>=45&&angleGap(a,45+f.direction*75)<=25)finish(true)}
 if(e.phase==='up'){
  if(f.action==='resize'&&Math.abs(Math.max(Math.abs(p.x-50),Math.abs(p.y-50))*2-(45+f.color*10))<=10)finish(true);
  if(f.action==='connect'&&st.from!==undefined){const order=f.direction%2?[2,0,1]:[1,2,0];if(distance(p,{x:82,y:20+order.indexOf(st.from)*30})<16){st.links.push(st.from);if(st.links.length===3)finish(true)}}
  if(f.action==='drag')finish(Math.abs(p.x-f.x)<=20&&Math.abs(p.y-f.y)<=22);
  if(f.action==='swipe'){const dx=p.x-st.start.x,dy=p.y-st.start.y,d=Math.abs(dx)>Math.abs(dy)?dx>0?1:3:dy>0?2:0;finish(Math.max(Math.abs(dx),Math.abs(dy))>=5&&d===f.direction)}
  st.down=false;
 }st.last=p;
}
