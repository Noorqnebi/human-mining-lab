/** Cloudflare Worker entry point for the vinext-starter template. */
import { handleImageOptimization, DEFAULT_DEVICE_SIZES, DEFAULT_IMAGE_SIZES } from "vinext/server/image-optimization";
import handler from "vinext/server/app-router-entry";

interface Env {
  HMC_TESTNET_URL?: string;
  ASSETS: Fetcher;
  DB: D1Database;
  IMAGES: {
    input(stream: ReadableStream): {
      transform(options: Record<string, unknown>): {
        output(options: { format: string; quality: number }): Promise<{ response(): Response }>;
      };
    };
  };
}

interface ExecutionContext {
  waitUntil(promise: Promise<unknown>): void;
  passThroughOnException(): void;
}

// Image security config. SVG sources with .svg extension auto-skip the
// optimization endpoint on the client side (served directly, no proxy).
// To route SVGs through the optimizer (with security headers), set
// dangerouslyAllowSVG: true in next.config.js and uncomment below:
// const imageConfig: ImageConfig = { dangerouslyAllowSVG: true };

const worker = {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/testnet/")) {
      if (!env.HMC_TESTNET_URL) return Response.json({error:"No persistent testnet server is configured. Configure the private HTTPS oracle endpoint."},{status:503});
      const upstream=new URL(env.HMC_TESTNET_URL);
      if(upstream.protocol!=="https:") return Response.json({error:"Testnet gateway requires HTTPS"},{status:503});
      const path=url.pathname.slice("/api/testnet".length);
      if(!/^\/(state|block|transaction|broadcast|session\/(start|pulse|begin|certificate|submit))$/.test(path))return new Response("Not found",{status:404});
      upstream.pathname=upstream.pathname.replace(/\/$/,"")+path;upstream.search=url.search;
      const headers=new Headers();headers.set("Content-Type","application/json");
      const authorization=request.headers.get("Authorization");if(authorization)headers.set("Authorization",authorization);
      const response=await fetch(upstream,{method:request.method,headers,body:request.method==='POST'?request.body:undefined,redirect:'error'});
      return new Response(response.body,{status:response.status,headers:{"Content-Type":"application/json","Cache-Control":"no-store"}});
    }
    if (url.pathname === "/_vinext/image") {
      const allowedWidths = [...DEFAULT_DEVICE_SIZES, ...DEFAULT_IMAGE_SIZES];
      return handleImageOptimization(request, {
        fetchAsset: (path) => env.ASSETS.fetch(new Request(new URL(path, request.url))),
        transformImage: async (body, { width, format, quality }) => {
          const result = await env.IMAGES.input(body).transform(width > 0 ? { width } : {}).output({ format, quality });
          return result.response();
        },
      }, allowedWidths);
    }

    return handler.fetch(request, env, ctx);
  },
};

export default worker;
